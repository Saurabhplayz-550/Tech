package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PreferencesManager
import com.example.service.ActionProcessor
import com.example.service.GeminiService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
class ActionProcessorTest {

    private lateinit var actionProcessor: ActionProcessor
    private lateinit var prefsManager: PreferencesManager

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        prefsManager = PreferencesManager(context)
        val geminiService = GeminiService()
        actionProcessor = ActionProcessor(context, prefsManager, geminiService)
    }

    @Test
    fun testWordBoundaryMatching_preventsFalsePositives() {
        // "express" must not match "press"
        assertFalse(actionProcessor.containsWord("express yourself", "press"))

        // "tired" must not match "red"
        assertFalse(actionProcessor.containsWord("i am tired today", "red"))

        // "shared" must not match "red"
        assertFalse(actionProcessor.containsWord("we shared files", "red"))

        // "book" must not match "ok"
        assertFalse(actionProcessor.containsWord("read this book", "ok"))

        // True positives
        assertTrue(actionProcessor.containsWord("please press the button", "press"))
        assertTrue(actionProcessor.containsWord("click send button", "send"))
        assertTrue(actionProcessor.containsWord("click send button", "click"))
        assertTrue(actionProcessor.containsWord("व्हाट्सएप पर मैसेज भेजो", "व्हाट्सएप"))
        assertTrue(actionProcessor.containsWord("व्हाट्सएप पर मैसेज भेजो", "भेजो"))
    }

    @Test
    fun testExtractButtonTarget_handlesBothWordOrdersAndSkipsFiller() {
        // "click send button"
        assertEquals("send", actionProcessor.extractButtonTarget("click send button"))

        // "send button dabao"
        assertEquals("send", actionProcessor.extractButtonTarget("send button dabao"))

        // "submit button दबाओ"
        assertEquals("submit", actionProcessor.extractButtonTarget("submit button दबाओ"))

        // Skipping filler words ("on", "the", "this")
        assertEquals("next", actionProcessor.extractButtonTarget("click on the next button"))

        // "ok button click karo"
        assertEquals("ok", actionProcessor.extractButtonTarget("ok button click karo"))
    }

    @Test
    fun testWhatsAppExtraction_extractsMessageAndContact() {
        // "send hello on whatsapp"
        val (_, msg1) = actionProcessor.parseWhatsAppCommand("send hello on whatsapp")
        assertEquals("hello", msg1)

        // "whatsapp pe good morning bhejo"
        val (_, msg2) = actionProcessor.parseWhatsAppCommand("whatsapp pe good morning bhejo")
        assertEquals("good morning", msg2)

        // "send message to mom how are you"
        val (contact, msg3) = actionProcessor.parseWhatsAppCommand("send message to mom how are you")
        assertEquals("mom", contact.lowercase())
        assertEquals("how are you", msg3)
    }

    @Test
    fun testWakeWordStripping_stripsWakeWordProperly() {
        prefsManager.wakeWord = "hey techchat"

        // "hey techchat open youtube" -> "open youtube"
        val stripped1 = actionProcessor.stripWakeWord("hey techchat open youtube")
        assertEquals("open youtube", stripped1)

        // Only wake word -> blank
        val stripped2 = actionProcessor.stripWakeWord("hey techchat")
        assertEquals("", stripped2)

        // Devanagari wake word: "हे टेकचैट यूट्यूब खोलो" -> "यूट्यूब खोलो"
        val stripped3 = actionProcessor.stripWakeWord("हे टेकचैट यूट्यूब खोलो")
        assertEquals("यूट्यूब खोलो", stripped3)
    }
}
