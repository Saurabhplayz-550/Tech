package com.example.service

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.PreferencesManager
import com.example.ui.hologram.BlueHologramCore
import com.example.ui.theme.TechChatTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Always-on background assistant.
 *
 * - Runs as a foreground service (survives the app being closed / removed from recents).
 * - Keeps listening for the wake word ("Hey TechChat") with NOTHING visible on screen.
 * - On wake word, only the hologram appears (transparent window, touches pass through to the app below),
 *   handles the command(s), then disappears again.
 */
class TechChatOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "TechChatOverlayService"
        private const val CHANNEL_ID = "techchat_service_channel"
        private const val NOTIFICATION_ID = 2001
        private const val HIDE_DELAY_MS = 7000L

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SUMMON = "ACTION_SUMMON"

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()

        val isRunning: Boolean get() = _isRunningFlow.value

        /** Lets the screenshot code hide the hologram for a split second so it is not captured. */
        @Volatile
        var hologramVisibilityHook: ((Boolean) -> Unit)? = null
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null

    private lateinit var prefsManager: PreferencesManager
    private val geminiService = GeminiService()
    private lateinit var actionProcessor: ActionProcessor
    private lateinit var voiceEngine: VoiceEngine

    private val handler = Handler(Looper.getMainLooper())
    private var hologramShown = false

    private val hideRunnable = Runnable { hideHologram() }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        prefsManager = PreferencesManager(this)
        actionProcessor = ActionProcessor(this, prefsManager, geminiService)
        voiceEngine = VoiceEngine.getInstance(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        createNotificationChannel()

        voiceEngine.registerListener(VoiceClient.OVERLAY) { command ->
            processOverlayVoiceCommand(command)
        }

        hologramVisibilityHook = { visible ->
            handler.post {
                overlayView?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefsManager.isOverlayEnabled = false
                hideHologram()
                voiceEngine.stopContinuousListening(VoiceClient.OVERLAY)
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }

            else -> {
                // Must go foreground right away (we may have been started with startForegroundService)
                startForeground(NOTIFICATION_ID, createNotification())

                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(
                        this,
                        "Overlay permission is required to display TechChat AI",
                        Toast.LENGTH_LONG
                    ).show()
                    stopForeground(true)
                    stopSelf()
                    return START_NOT_STICKY
                }

                prefsManager.isOverlayEnabled = true
                _isRunningFlow.value = true

                if (intent?.action == ACTION_SUMMON) {
                    summonHologram("How can I assist you, sir?")
                } else {
                    startBackgroundListening()
                }
            }
        }
        // START_STICKY: the system recreates the service (with a null intent) if it gets killed
        return START_STICKY
    }

    // Silent standby: mic is open for the wake word, nothing is drawn on screen
    private fun startBackgroundListening() {
        if (voiceEngine.activeClient == VoiceClient.ACTIVITY) return // app is on screen and owns the mic
        if (voiceEngine.isListening.value && voiceEngine.activeClient == VoiceClient.OVERLAY) return
        voiceEngine.startContinuousListening(VoiceClient.OVERLAY)
    }

    private fun scheduleHide(delayMs: Long = HIDE_DELAY_MS) {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, delayMs)
    }

    private fun summonHologram(greeting: String) {
        showHologram()
        voiceEngine.speak(greeting) {
            scheduleHide()
        }
        if (voiceEngine.activeClient != VoiceClient.ACTIVITY) {
            voiceEngine.startContinuousListening(VoiceClient.OVERLAY)
        }
    }

    private fun processOverlayVoiceCommand(query: String) {
        if (voiceEngine.isProcessingAi) {
            Log.d(TAG, "Ignoring overlay voice input: AI request already in flight")
            return
        }

        val normalized = actionProcessor.normalizeText(query)
        if (normalized.isBlank()) return

        Log.i(TAG, "Overlay received voice: $query")

        val isWake = actionProcessor.isWakeWord(query)

        // Standby: ignore everything except the wake word
        if (!hologramShown && !isWake) {
            Log.d(TAG, "Ignored: standby and no wake word")
            return
        }

        val stripped = if (isWake) actionProcessor.stripWakeWord(query) else query

        // Only "Hey TechChat" was said
        if (isWake && stripped.isBlank()) {
            summonHologram("How can I assist you, sir?")
            return
        }

        val effectiveQuery = stripped.ifBlank { query }

        // Hologram stays on screen while we work
        showHologram()
        handler.removeCallbacks(hideRunnable)

        val fastResult = actionProcessor.tryExecuteFastPath(effectiveQuery)
        if (fastResult != null) {
            voiceEngine.speak(fastResult.spokenResponse) {
                scheduleHide(if (fastResult.dismissHologram) 300L else HIDE_DELAY_MS)
            }
            return
        }

        voiceEngine.isProcessingAi = true
        serviceScope.launch {
            try {
                val executionResult = actionProcessor.processWithGemini(effectiveQuery) { steps ->
                    // Read the plan out loud before starting
                    voiceEngine.speakAndWait(actionProcessor.planToSpeech(steps))
                }
                voiceEngine.speak(executionResult.spokenResponse) {
                    // Stay on screen longer when waiting for the user's answer
                    scheduleHide(if (executionResult.awaitingUserInput) 25_000L else HIDE_DELAY_MS)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Command failed", e)
                voiceEngine.speak("Something went wrong, sir.") { scheduleHide() }
            } finally {
                voiceEngine.isProcessingAi = false
            }
        }
    }

    private fun showHologram() {
        hologramShown = true
        handler.removeCallbacks(hideRunnable)
        if (overlayView != null) return

        // Touch-through: the hologram never blocks taps on the app underneath (and our own screen taps pass through it)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (72 * resources.displayMetrics.density).toInt()
        }

        val container = FrameLayout(this)
        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@TechChatOverlayService)
            setViewTreeSavedStateRegistryOwner(this@TechChatOverlayService)
            setContent {
                TechChatTheme {
                    val listening = voiceEngine.isListening.collectAsState().value
                    val speaking = voiceEngine.isSpeaking.collectAsState().value
                    val amp = voiceEngine.amplitude.collectAsState().value

                    // Hologram only - the window itself is fully transparent
                    BlueHologramCore(
                        coreSize = 240.dp,
                        isListening = listening,
                        isSpeaking = speaking,
                        audioAmplitude = amp
                    )
                }
            }
        }

        container.addView(composeView)

        try {
            windowManager.addView(container, params)
            overlayView = container
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlay view to WindowManager", e)
            overlayView = null
            hologramShown = false
        }
    }

    private fun hideHologram() {
        hologramShown = false
        handler.removeCallbacks(hideRunnable)
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing overlay", e)
            }
        }
        overlayView = null
    }

    // If the user swipes the app away and the OEM kills us, ask the system to bring us back.
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (_isRunningFlow.value && prefsManager.isOverlayEnabled) {
            try {
                val restart = Intent(applicationContext, TechChatOverlayService::class.java).apply {
                    action = ACTION_START
                    setPackage(packageName)
                }
                val pi = PendingIntent.getForegroundService(
                    applicationContext, 7, restart,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val alarms = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarms.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500L, pi)
            } catch (e: Exception) {
                Log.w(TAG, "Could not schedule restart", e)
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "TechChat Hologram Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps TechChat AI listening for \"Hey TechChat\""
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TechChat AI is listening")
            .setContentText("Say \"Hey TechChat\" anytime.")
            .setSmallIcon(R.drawable.ic_notification_core)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunningFlow.value = false
        handler.removeCallbacks(hideRunnable)
        hologramVisibilityHook = null
        hideHologram()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()

        voiceEngine.unregisterListener(VoiceClient.OVERLAY)
        voiceEngine.releaseClient(VoiceClient.OVERLAY)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
