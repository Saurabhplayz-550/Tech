package com.example.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.PreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

enum class VoiceClient {
    NONE,
    ACTIVITY,
    OVERLAY
}

class VoiceEngine private constructor(private val appContext: Context) {

    companion object {
        private const val TAG = "VoiceEngine"
        private const val TTS_SAFETY_TIMEOUT_MS = 20_000L

        @Volatile
        private var INSTANCE: VoiceEngine? = null

        fun getInstance(context: Context): VoiceEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VoiceEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val prefsManager = PreferencesManager(appContext)
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val pendingUtterances = mutableListOf<Pair<String, (() -> Unit)?>>()

    // Per-utterance completion callback registry (ConcurrentHashMap)
    private val utteranceCallbacks = ConcurrentHashMap<String, () -> Unit>()
    private val timeoutRunnables = ConcurrentHashMap<String, Runnable>()

    // State flows
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _spokenText = MutableStateFlow("")
    val spokenText: StateFlow<String> = _spokenText.asStateFlow()

    var activeClient: VoiceClient = VoiceClient.NONE
        private set
    private var isContinuousListeningRequested = false

    // AI processing guard to prevent command overlaps (Item 8)
    @Volatile
    var isProcessingAi: Boolean = false

    // Per-client listener map (Item 5)
    private val clientListeners = ConcurrentHashMap<VoiceClient, (String) -> Unit>()

    var onStatusChanged: ((isListening: Boolean, isSpeaking: Boolean) -> Unit)? = null

    // Recognizer backoff and retry
    private var busyRetryCount = 0
    private var backoffDelayMs = 400L

    // Notification stream muting state (Item 10)
    private var canMuteStream = true
    private var didMuteStream = false
    private val unmuteRunnable = Runnable {
        if (didMuteStream && canMuteStream) {
            try {
                audioManager?.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
                // Ignore
            }
            didMuteStream = false
        }
    }

    init {
        initTts()
    }

    fun registerListener(client: VoiceClient, listener: (String) -> Unit) {
        clientListeners[client] = listener
    }

    fun unregisterListener(client: VoiceClient) {
        clientListeners.remove(client)
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyTtsLanguage()
                textToSpeech?.setPitch(prefsManager.ttsPitch)
                textToSpeech?.setSpeechRate(prefsManager.ttsSpeed)

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        notifyStatus()
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            if (utteranceId != null) {
                                invokeAndRemoveCallback(utteranceId)
                            }
                            _isSpeaking.value = false
                            notifyStatus()
                            checkPendingTtsOrResumeMic()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            if (utteranceId != null) {
                                invokeAndRemoveCallback(utteranceId)
                            }
                            _isSpeaking.value = false
                            notifyStatus()
                            checkPendingTtsOrResumeMic()
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        mainHandler.post {
                            if (utteranceId != null) {
                                invokeAndRemoveCallback(utteranceId)
                            }
                            _isSpeaking.value = false
                            notifyStatus()
                            checkPendingTtsOrResumeMic()
                        }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        mainHandler.post {
                            if (utteranceId != null) {
                                invokeAndRemoveCallback(utteranceId)
                            }
                            _isSpeaking.value = false
                            notifyStatus()
                            checkPendingTtsOrResumeMic()
                        }
                    }
                })

                isTtsInitialized = true
                Log.i(TAG, "TTS successfully initialized")

                // Flush any queued utterances
                synchronized(pendingUtterances) {
                    val queueCopy = ArrayList(pendingUtterances)
                    pendingUtterances.clear()
                    for ((text, callback) in queueCopy) {
                        speakInternal(text, callback)
                    }
                }
            } else {
                Log.e(TAG, "Failed to initialize TextToSpeech")
                isTtsInitialized = false
                _isSpeaking.value = false
                notifyStatus()

                // Flush pending callbacks so callers are never left hanging (Item 9)
                synchronized(pendingUtterances) {
                    for ((_, cb) in pendingUtterances) {
                        cb?.invoke()
                    }
                    pendingUtterances.clear()
                }
            }
        }
    }

    private fun invokeAndRemoveCallback(utteranceId: String) {
        timeoutRunnables.remove(utteranceId)?.let { mainHandler.removeCallbacks(it) }
        utteranceCallbacks.remove(utteranceId)?.invoke()
    }

    fun applyTtsLanguage() {
        val tts = textToSpeech ?: return
        val prefLang = prefsManager.voiceLanguage
        val targetLocale = when (prefLang) {
            "hi-IN" -> Locale("hi", "IN")
            "en-US" -> Locale.ENGLISH
            else -> {
                val sysLocale = Locale.getDefault()
                val testRes = tts.isLanguageAvailable(sysLocale)
                if (testRes >= TextToSpeech.LANG_AVAILABLE) sysLocale else Locale.ENGLISH
            }
        }

        val res = tts.setLanguage(targetLocale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.ENGLISH
        }
    }

    fun setClientInForeground(client: VoiceClient) {
        if (activeClient == client) return
        Log.i(TAG, "Switching voice client from $activeClient to $client")
        stopListening()
        activeClient = client
    }

    fun releaseClient(client: VoiceClient) {
        if (activeClient == client) {
            stopListening()
            activeClient = VoiceClient.NONE
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!prefsManager.isSpeechFeedbackEnabled) {
            _isSpeaking.value = false
            notifyStatus()
            onDone?.invoke()
            return
        }

        if (!isTtsInitialized) {
            synchronized(pendingUtterances) {
                pendingUtterances.add(text to onDone)
            }
            return
        }

        speakInternal(text, onDone)
    }

    /** Speaks and suspends until the speech has finished (or failed / timed out). */
    suspend fun speakAndWait(text: String) {
        suspendCancellableCoroutine<Unit> { cont ->
            speak(text) {
                if (cont.isActive) cont.resume(Unit)
            }
        }
    }

    private fun speakInternal(text: String, onDone: (() -> Unit)?) {
        // Temporarily pause recognizer during speech output
        stopListening(temporaryForSpeech = true)

        // Clear previous active callbacks because QUEUE_FLUSH interrupts previous utterance (Item 1)
        for ((uid, cb) in utteranceCallbacks) {
            timeoutRunnables.remove(uid)?.let { mainHandler.removeCallbacks(it) }
            cb.invoke()
        }
        utteranceCallbacks.clear()

        _isSpeaking.value = true
        notifyStatus()

        val utteranceId = UUID.randomUUID().toString()
        if (onDone != null) {
            utteranceCallbacks[utteranceId] = onDone
        }

        // Safety timeout (20s) so status never stays stuck in SPEAKING (Item 9)
        val safetyTimeout = Runnable {
            Log.w(TAG, "TTS safety timeout fired for utterance: $utteranceId")
            invokeAndRemoveCallback(utteranceId)
            _isSpeaking.value = false
            notifyStatus()
            checkPendingTtsOrResumeMic()
        }
        timeoutRunnables[utteranceId] = safetyTimeout
        mainHandler.postDelayed(safetyTimeout, TTS_SAFETY_TIMEOUT_MS)

        val result = textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            Log.e(TAG, "textToSpeech.speak() failed with result $result")
            invokeAndRemoveCallback(utteranceId)
            _isSpeaking.value = false
            notifyStatus()
            checkPendingTtsOrResumeMic()
        }
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        for ((uid, cb) in utteranceCallbacks) {
            timeoutRunnables.remove(uid)?.let { mainHandler.removeCallbacks(it) }
            cb.invoke()
        }
        utteranceCallbacks.clear()
        _isSpeaking.value = false
        notifyStatus()
        checkPendingTtsOrResumeMic()
    }

    private fun checkPendingTtsOrResumeMic() {
        synchronized(pendingUtterances) {
            if (pendingUtterances.isNotEmpty()) {
                val (nextText, nextCallback) = pendingUtterances.removeAt(0)
                speakInternal(nextText, nextCallback)
                return
            }
        }

        // Resume continuous listening if active and not in middle of AI query
        if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
            mainHandler.postDelayed({
                if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                    startListeningInternal()
                }
            }, 300)
        }
    }

    fun startContinuousListening(client: VoiceClient) {
        activeClient = client
        isContinuousListeningRequested = true
        startListeningInternal()
    }

    fun stopContinuousListening(client: VoiceClient) {
        if (activeClient == client || client == VoiceClient.NONE) {
            isContinuousListeningRequested = false
            stopListening()
        }
    }

    fun toggleListening(client: VoiceClient) {
        if (_isListening.value) {
            stopContinuousListening(client)
        } else {
            startContinuousListening(client)
        }
    }

    private fun startListeningInternal() {
        if (_isSpeaking.value || isProcessingAi) {
            Log.d(TAG, "Recognize start delayed: TTS speaking or AI processing in flight")
            return
        }

        val hasPermission = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            Log.w(TAG, "Microphone permission not granted")
            _isListening.value = false
            notifyStatus()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            Log.w(TAG, "SpeechRecognizer is not available")
            _isListening.value = false
            notifyStatus()
            return
        }

        brieflyMuteBeep()
        ensureRecognizer()

        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                val prefLang = prefsManager.voiceLanguage
                val recognitionLocale = when (prefLang) {
                    "hi-IN" -> "hi-IN"
                    "en-US" -> "en-US"
                    else -> Locale.getDefault().toLanguageTag()
                }
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionLocale)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            }
            speechRecognizer?.startListening(intent)
            _isListening.value = true
            notifyStatus()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening", e)
            _isListening.value = false
            notifyStatus()
            scheduleRestartWithBackoff()
        }
    }

    private fun stopListening(temporaryForSpeech: Boolean = false) {
        if (!temporaryForSpeech) {
            isContinuousListeningRequested = false
        }
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping SpeechRecognizer", e)
        }
        _isListening.value = false
        _amplitude.value = 0f
        notifyStatus()
    }

    private fun brieflyMuteBeep() {
        if (!canMuteStream || audioManager == null) return
        try {
            val isMuted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                audioManager.isStreamMute(AudioManager.STREAM_NOTIFICATION)
            } else {
                audioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION) == 0
            }

            if (!isMuted && !didMuteStream) {
                audioManager.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
                didMuteStream = true
                mainHandler.removeCallbacks(unmuteRunnable)
                mainHandler.postDelayed(unmuteRunnable, 220L)
            }
        } catch (e: SecurityException) {
            canMuteStream = false
            didMuteStream = false
        } catch (e: Exception) {
            // Volume adjustment permission or device restriction
        }
    }

    private fun ensureRecognizer() {
        if (speechRecognizer != null) return

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                    busyRetryCount = 0
                    backoffDelayMs = 400L
                    notifyStatus()
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    _amplitude.value = (rmsdB / 10f).coerceIn(0f, 1f)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _amplitude.value = 0f
                    notifyStatus()
                }

                override fun onError(errorCode: Int) {
                    _isListening.value = false
                    _amplitude.value = 0f
                    notifyStatus()

                    handleRecognizerError(errorCode)
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _amplitude.value = 0f
                    notifyStatus()

                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.trim() ?: ""
                    if (text.isNotBlank()) {
                        _spokenText.value = text

                        // If AI request is currently in flight, avoid overlapping duplicate commands (Item 8)
                        if (!isProcessingAi) {
                            clientListeners[activeClient]?.invoke(text)
                        }
                    }

                    // Only restart if not currently speaking and no AI request in flight
                    if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                        mainHandler.postDelayed({
                            if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                                startListeningInternal()
                            }
                        }, 500)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    if (text.isNotBlank()) {
                        _spokenText.value = text
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun handleRecognizerError(errorCode: Int) {
        if (!isContinuousListeningRequested || _isSpeaking.value || isProcessingAi) return

        when (errorCode) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                mainHandler.postDelayed({
                    if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                        startListeningInternal()
                    }
                }, 400)
            }

            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                busyRetryCount++
                if (busyRetryCount <= 3) {
                    destroyRecognizer()
                    mainHandler.postDelayed({
                        if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                            startListeningInternal()
                        }
                    }, 650)
                } else {
                    Log.w(TAG, "Recognizer busy max retries exceeded")
                    busyRetryCount = 0
                    scheduleRestartWithBackoff()
                }
            }

            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                Log.e(TAG, "Insufficient permissions for SpeechRecognizer")
                isContinuousListeningRequested = false
            }

            else -> {
                scheduleRestartWithBackoff()
            }
        }
    }

    private fun scheduleRestartWithBackoff() {
        if (!isContinuousListeningRequested || _isSpeaking.value || isProcessingAi) return
        mainHandler.postDelayed({
            if (isContinuousListeningRequested && !_isSpeaking.value && !isProcessingAi) {
                startListeningInternal()
            }
        }, backoffDelayMs)
        backoffDelayMs = (backoffDelayMs * 2).coerceAtMost(4000L)
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
        speechRecognizer = null
    }

    private fun notifyStatus() {
        onStatusChanged?.invoke(_isListening.value, _isSpeaking.value)
    }

    fun shutdown() {
        destroyRecognizer()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        isTtsInitialized = false
        clientListeners.clear()
        utteranceCallbacks.clear()
        timeoutRunnables.clear()
    }
}
