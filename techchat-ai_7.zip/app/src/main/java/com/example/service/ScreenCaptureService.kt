package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Gives the AI real eyes: keeps the newest frame of the screen so a screenshot can be sent to Gemini
 * the moment a command arrives. Needs the one-time "Start recording or casting" approval.
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val TAG = "ScreenCaptureService"
        private const val CHANNEL_ID = "techchat_capture_channel"
        private const val NOTIFICATION_ID = 2002
        private const val MAX_SIDE = 1280

        const val EXTRA_CODE = "projection_code"
        const val EXTRA_DATA = "projection_data"

        private val _isActive = MutableStateFlow(false)
        val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

        @Volatile
        private var instance: ScreenCaptureService? = null

        /** Latest screen as a base64 JPEG (scaled down), or null if capture is not running. */
        suspend fun captureJpegBase64(): String? = withContext(Dispatchers.Default) {
            try {
                instance?.grabFrameAsJpegBase64()
            } catch (e: Exception) {
                Log.w(TAG, "Screenshot failed", e)
                null
            }
        }
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val lock = Any()
    private var latestImage: Image? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NOTIFICATION_ID,
            createNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || code == 0) {
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        releaseCapture()

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))

            val (w, h) = realScreenSize(this)
            val dpi = resources.displayMetrics.densityDpi

            val t = HandlerThread("techchat-capture").also { it.start() }
            thread = t
            val handler = Handler(t.looper)

            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    synchronized(lock) {
                        latestImage?.close()
                        latestImage = img
                    }
                }
            }, handler)
            imageReader = reader

            virtualDisplay = mp.createVirtualDisplay(
                "techchat-capture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )

            instance = this
            _isActive.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Could not start screen capture", e)
            stopForeground(true)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun grabFrameAsJpegBase64(): String? {
        var bitmap: Bitmap? = null
        synchronized(lock) {
            val img = latestImage ?: return null
            val plane = img.planes[0]
            val buffer = plane.buffer
            buffer.rewind()
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val padded = Bitmap.createBitmap(
                img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)
            bitmap = if (padded.width != img.width) {
                val cropped = Bitmap.createBitmap(padded, 0, 0, img.width, img.height)
                padded.recycle()
                cropped
            } else {
                padded
            }
        }

        val full = bitmap ?: return null
        val longest = maxOf(full.width, full.height)
        val scaled = if (longest > MAX_SIDE) {
            val f = MAX_SIDE.toFloat() / longest
            Bitmap.createScaledBitmap(full, (full.width * f).toInt(), (full.height * f).toInt(), true)
        } else {
            full
        }

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
        if (scaled !== full) scaled.recycle()
        full.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun releaseCapture() {
        try { virtualDisplay?.release() } catch (e: Exception) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (e: Exception) {}
        imageReader = null
        synchronized(lock) {
            try { latestImage?.close() } catch (e: Exception) {}
            latestImage = null
        }
        try { projection?.stop() } catch (e: Exception) {}
        projection = null
        thread?.quitSafely()
        thread = null
    }

    private fun createNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "TechChat Screen Vision", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TechChat AI can see your screen")
            .setContentText("Only used when you give a voice command.")
            .setSmallIcon(R.drawable.ic_notification_core)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isActive.value = false
        releaseCapture()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
