package com.example.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** One tappable / readable thing on screen, numbered so the AI can say "tap #7". */
data class ScreenElement(
    val index: Int,
    val label: String,
    val kind: String,
    val bounds: Rect,
    val clickable: Boolean,
    val editable: Boolean
)

class TechChatAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "TechChatAccessibility"
        private const val DEBOUNCE_MS = 500L
        private const val MAX_SUMMARY_LENGTH = 2000
        private const val MAX_ELEMENTS = 150
        private const val MAX_ELEMENTS_CHARS = 7000
        private val HIDDEN_ID_REGEX = Regex("(password|cvv|(^|[^a-z])(otp|pin)([^a-z]|$))")

        /** Snapshot of the last captured screen, used to resolve "tap element N". */
        @Volatile
        var lastElements: List<ScreenElement> = emptyList()
            private set

        var instance: TechChatAccessibilityService? = null
            private set

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        private val _lastScreenSummary = MutableStateFlow("")
        val lastScreenSummary: StateFlow<String> = _lastScreenSummary.asStateFlow()

        // Sensitive package list (Item 25)
        private val SENSITIVE_PACKAGE_KEYWORDS = listOf(
            "bank", "paytm", "gpay", "phonepe", "bhim", "cred", "wallet",
            "authenticator", "password", "lastpass", "bitwarden", "1password", "keepass",
            "com.google.android.apps.nbu.paisa", "paisa", "upi", "mobikwik", "razorpay",
            "payu", "sbi", "hdfc", "icici", "axis", "kotak", "yono", "netbanking",
            "totp", "otp", "keystore", "vault", "authy"
        )
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var debounceJob: Job? = null
    private lateinit var prefsManager: PreferencesManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefsManager = PreferencesManager(this)
        _isServiceActive.value = true
        Log.i(TAG, "TechChat Accessibility Service connected")
        maybeStartOverlayService()
    }

    // The system restarts accessibility services on its own (even after the app was swiped away),
    // so use that as a second way to bring the "Hey TechChat" listener back.
    private fun maybeStartOverlayService() {
        try {
            if (prefsManager.isOverlayEnabled &&
                Settings.canDrawOverlays(this) &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED &&
                !TechChatOverlayService.isRunning
            ) {
                val intent = Intent(this, TechChatOverlayService::class.java).apply {
                    action = TechChatOverlayService.ACTION_START
                }
                ContextCompat.startForegroundService(this, intent)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not auto-start overlay service", e)
        }
    }

    // The screen is read on demand (captureScreenElements) right when a command arrives,
    // so nothing needs to run on every window change. This keeps battery use low for always-on listening.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    private fun isSensitivePackage(pkgName: String): Boolean {
        return SENSITIVE_PACKAGE_KEYWORDS.any { pkgName.contains(it) }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceActive.value = false
        debounceJob?.cancel()
    }

    fun goHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun goBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun openNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun openRecents(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun updateScreenContext(): String {
        return updateScreenContextInternal()
    }

    private fun updateScreenContextInternal(): String {
        // Collect screen context ONLY when "Share screen content with AI" is ON (Item 26)
        if (!prefsManager.isShareScreenEnabled) {
            _lastScreenSummary.value = ""
            return ""
        }

        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return ""
        try {
            val rootPkg = root.packageName?.toString()?.lowercase() ?: ""
            if (isSensitivePackage(rootPkg)) {
                val protectedMsg = "[Sensitive App: content hidden]"
                _lastScreenSummary.value = protectedMsg
                return protectedMsg
            }

            val builder = StringBuilder()
            traverseSafe(root, builder, 0)
            val full = builder.toString().trim()
            val capped = if (full.length > MAX_SUMMARY_LENGTH) full.take(MAX_SUMMARY_LENGTH) + "..." else full
            _lastScreenSummary.value = capped
            return capped
        } finally {
            try { root.recycle() } catch (e: Exception) {}
        }
    }

    // Traverses tree recycling each created child node exactly once in finally block (Item 23)
    private fun traverseSafe(node: AccessibilityNodeInfo, builder: StringBuilder, depth: Int) {
        if (depth > 8 || builder.length >= MAX_SUMMARY_LENGTH) return

        val viewId = node.viewIdResourceName?.lowercase() ?: ""
        // Skip whole subtree if password, pin, otp or cvv (Item 25)
        if (node.isPassword || viewId.contains("password") || viewId.contains("pin") ||
            viewId.contains("otp") || viewId.contains("cvv")
        ) {
            return
        }

        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        if (!text.isNullOrBlank() || !desc.isNullOrBlank()) {
            val label = when {
                !text.isNullOrBlank() && !desc.isNullOrBlank() -> "$text ($desc)"
                !text.isNullOrBlank() -> text
                else -> desc
            }
            val clickable = if (node.isClickable) " [Clickable]" else ""
            builder.append("• ").append(label).append(clickable).append("\n")
        }

        val childCount = node.childCount
        for (i in 0 until childCount) {
            val child = try { node.getChild(i) } catch (e: Exception) { null }
            if (child != null) {
                try {
                    traverseSafe(child, builder, depth + 1)
                } finally {
                    try { child.recycle() } catch (e: Exception) {}
                }
            }
        }
    }

    fun clickNodeWithText(query: String): Boolean {
        val target = query.trim()
        if (target.isBlank()) return false

        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(target) ?: emptyList()
        var clicked = false

        try {
            // Prefer exact match, visible and enabled (Item 27)
            val exactMatch = nodes.firstOrNull {
                val t = it.text?.toString() ?: ""
                val d = it.contentDescription?.toString() ?: ""
                it.isVisibleToUser && it.isEnabled &&
                    (t.equals(target, ignoreCase = true) || d.equals(target, ignoreCase = true))
            } ?: nodes.firstOrNull { it.isVisibleToUser && it.isEnabled }

            if (exactMatch != null) {
                clicked = performClick(exactMatch)
            }
        } finally {
            for (n in nodes) {
                try { n.recycle() } catch (e: Exception) {}
            }
            try { root.recycle() } catch (e: Exception) {}
        }

        return clicked
    }

    fun clickProminentActionButton(targetLabel: String = ""): Boolean {
        val target = targetLabel.trim().lowercase()
        if (target.isBlank()) return false

        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        var clicked = false

        try {
            // Find clickable, visible and enabled node matching target (Item 27)
            val targetNode = findMatchingClickableNode(root, target)
            if (targetNode != null) {
                try {
                    clicked = performClick(targetNode)
                } finally {
                    try { targetNode.recycle() } catch (e: Exception) {}
                }
            }
        } finally {
            try { root.recycle() } catch (e: Exception) {}
        }

        return clicked
    }

    private fun findMatchingClickableNode(
        node: AccessibilityNodeInfo,
        target: String
    ): AccessibilityNodeInfo? {
        if (!node.isVisibleToUser || !node.isEnabled) return null

        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val id = node.viewIdResourceName?.lowercase() ?: ""

        val isMatch = text.equals(target, ignoreCase = true) ||
            desc.equals(target, ignoreCase = true) ||
            text.contains("\\b$target\\b".toRegex()) ||
            desc.contains("\\b$target\\b".toRegex()) ||
            id.contains(target)

        if (isMatch && node.isClickable) {
            return AccessibilityNodeInfo.obtain(node)
        }

        val childCount = node.childCount
        for (i in 0 until childCount) {
            val child = try { node.getChild(i) } catch (e: Exception) { null }
            if (child != null) {
                try {
                    val match = findMatchingClickableNode(child, target)
                    if (match != null) {
                        return match
                    }
                } finally {
                    try { child.recycle() } catch (e: Exception) {}
                }
            }
        }

        return null
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (success) return true
        }

        // Try parent if not directly clickable
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) {
                val ok = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                try { parent.recycle() } catch (e: Exception) {}
                if (ok) return true
                break
            }
            val nextParent = parent.parent
            try { parent.recycle() } catch (e: Exception) {}
            parent = nextParent
        }

        // Fallback: Gesture click using node screen bounds
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (!bounds.isEmpty) {
            return clickCoordinates(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        }

        return false
    }

    fun clickCoordinates(x: Float, y: Float): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun typeTextIntoFocused(text: String): Boolean {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        var success = false
        try {
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null) {
                try {
                    val arguments = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                    }
                    success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
                } finally {
                    try { focused.recycle() } catch (e: Exception) {}
                }
            }
        } finally {
            try { root.recycle() } catch (e: Exception) {}
        }
        return success
    }

    // ---------------------------------------------------------------------------------
    // Screen "vision" (UI tree with positions) + touch gestures
    // ---------------------------------------------------------------------------------

    /**
     * Reads everything visible in the active window as a numbered list with positions.
     * Android 10 has no screenshot API for accessibility services, so this is how the AI "sees".
     */
    fun captureScreenElements(): String {
        if (!::prefsManager.isInitialized || !prefsManager.isShareScreenEnabled) return ""

        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return ""
        val (screenW, screenH) = realScreenSize(this)
        val pkg = root.packageName?.toString() ?: ""

        try {
            if (isSensitivePackage(pkg.lowercase())) {
                lastElements = emptyList()
                return "[Sensitive App: content hidden]"
            }

            val found = ArrayList<ScreenElement>()
            collectElements(root, found, 0)
            lastElements = found

            val sb = StringBuilder()
            sb.append("Screen ${screenW}x${screenH} px, app: $pkg\n")
            for (el in found) {
                val line = StringBuilder()
                line.append("#").append(el.index).append(' ').append(el.kind)
                if (el.label.isNotEmpty()) line.append(" \"").append(el.label).append('"')
                line.append(" @(").append(el.bounds.centerX()).append(',').append(el.bounds.centerY()).append(')')
                if (el.editable) line.append(" [input]") else if (el.clickable) line.append(" [tap]")
                line.append('\n')
                if (sb.length + line.length > MAX_ELEMENTS_CHARS) break
                sb.append(line)
            }
            return sb.toString().trim()
        } finally {
            try { root.recycle() } catch (e: Exception) {}
        }
    }

    private fun collectElements(node: AccessibilityNodeInfo, out: MutableList<ScreenElement>, depth: Int) {
        if (depth > 30 || out.size >= MAX_ELEMENTS) return
        if (!node.isVisibleToUser) return

        val viewId = node.viewIdResourceName?.lowercase() ?: ""
        if (node.isPassword || HIDDEN_ID_REGEX.containsMatchIn(viewId)) return

        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val label = when {
            text.isNotEmpty() && desc.isNotEmpty() && text != desc -> "$text / $desc"
            text.isNotEmpty() -> text
            else -> desc
        }.replace("\n", " ").take(80)

        val clickable = node.isClickable || node.isLongClickable
        val editable = node.isEditable
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val worthListing = label.isNotEmpty() || editable || (clickable && node.childCount == 0)
        if (worthListing && bounds.width() > 0 && bounds.height() > 0) {
            val kind = node.className?.toString()?.substringAfterLast('.') ?: "View"
            out.add(ScreenElement(out.size + 1, label, kind, bounds, clickable, editable))
        }

        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (e: Exception) { null } ?: continue
            try {
                collectElements(child, out, depth + 1)
            } finally {
                try { child.recycle() } catch (e: Exception) {}
            }
        }
    }

    fun elementLabel(index: Int): String {
        return lastElements.firstOrNull { it.index == index }?.label ?: ""
    }

    fun tapElement(index: Int): Boolean {
        val el = lastElements.firstOrNull { it.index == index } ?: return false
        return clickCoordinates(el.bounds.exactCenterX(), el.bounds.exactCenterY())
    }

    fun tapAt(x: Float, y: Float): Boolean = clickCoordinates(x, y)

    // The AI answers screenshot positions as 0..1000 (0,0 = top-left, 1000,1000 = bottom-right)
    fun tapNormalized(nx: Float, ny: Float): Boolean {
        val (w, h) = realScreenSize(this)
        return clickCoordinates(nx.coerceIn(0f, 1000f) / 1000f * w, ny.coerceIn(0f, 1000f) / 1000f * h)
    }

    fun longPressNormalized(nx: Float, ny: Float): Boolean {
        val (w, h) = realScreenSize(this)
        return longPressAt(nx.coerceIn(0f, 1000f) / 1000f * w, ny.coerceIn(0f, 1000f) / 1000f * h)
    }

    fun longPressElement(index: Int): Boolean {
        val el = lastElements.firstOrNull { it.index == index } ?: return false
        return longPressAt(el.bounds.exactCenterX(), el.bounds.exactCenterY())
    }

    fun longPressAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 900))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * direction = which way the content should move to reveal more:
     * "down" = see content further down (finger swipes up), "up" = go back up,
     * "right" = next page to the right (finger swipes left), "left" = previous page.
     */
    fun scroll(direction: String): Boolean {
        val (sw, sh) = realScreenSize(this)
        val w = sw.toFloat()
        val h = sh.toFloat()
        val path = Path()
        when (direction.lowercase().trim()) {
            "down" -> { path.moveTo(w * 0.5f, h * 0.72f); path.lineTo(w * 0.5f, h * 0.28f) }
            "up" -> { path.moveTo(w * 0.5f, h * 0.28f); path.lineTo(w * 0.5f, h * 0.72f) }
            "right" -> { path.moveTo(w * 0.85f, h * 0.5f); path.lineTo(w * 0.15f, h * 0.5f) }
            "left" -> { path.moveTo(w * 0.15f, h * 0.5f); path.lineTo(w * 0.85f, h * 0.5f) }
            else -> return false
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
