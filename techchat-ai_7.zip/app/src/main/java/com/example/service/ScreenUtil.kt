package com.example.service

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

/** Real physical screen size in pixels (what touch gestures and screenshots use). */
fun realScreenSize(context: Context): Pair<Int, Int> {
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val dm = DisplayMetrics()
    @Suppress("DEPRECATION")
    wm.defaultDisplay.getRealMetrics(dm)
    return Pair(dm.widthPixels, dm.heightPixels)
}
