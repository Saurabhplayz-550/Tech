package com.example.service

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.PreferencesManager

/** Restarts the always-on "Hey TechChat" listener after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != "android.intent.action.QUICKBOOT_POWERON") return

        try {
            val prefs = PreferencesManager(context)
            if (!prefs.isOverlayEnabled || !Settings.canDrawOverlays(context)) return
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) return

            val start = Intent(context, TechChatOverlayService::class.java).apply {
                this.action = TechChatOverlayService.ACTION_START
            }
            ContextCompat.startForegroundService(context, start)
        } catch (e: Exception) {
            Log.w("BootReceiver", "Could not start TechChat after boot", e)
        }
    }
}
