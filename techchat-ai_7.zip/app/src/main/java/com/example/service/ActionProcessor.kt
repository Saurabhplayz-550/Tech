package com.example.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import com.example.data.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class ExecutionResult(
    val success: Boolean,
    val spokenResponse: String,
    val isSystemAction: Boolean,
    val showHologramFace: Boolean = false,
    val awaitingConfirmation: Boolean = false,
    val dismissHologram: Boolean = false,
    val awaitingUserInput: Boolean = false
)

class ActionProcessor(
    private val context: Context,
    private val prefsManager: PreferencesManager,
    private val geminiService: GeminiService
) {
    companion object {
        private const val TAG = "ActionProcessor"

        private val APP_ALIASES = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "camera" to "com.google.android.GoogleCamera",
            "settings" to "com.android.settings",
            "phone" to "com.google.android.dialer",
            "messages" to "com.google.android.apps.messaging",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana"
        )

        // Blocklist for dangerous automated actions (Item 16)
        private val DANGEROUS_BUTTON_KEYWORDS = listOf(
            "pay", "send money", "transfer", "delete", "uninstall",
            "confirm payment", "buy now", "factory reset", "format"
        )

        private const val MAX_AGENT_STEPS = 12

        // Ways the speech recognizer may spell the wake word
        private val WAKE_VARIANTS = listOf(
            "hey techchat", "hey tech chat", "techchat", "tech chat", "tek chat", "techchart",
            "हे टेकचैट", "टेकचैट", "टेक चैट"
        )

        private val DISMISS_PHRASES = setOf(
            "thank you", "thanks", "thank you techchat", "that s all", "that is all", "bas",
            "bas itna hi", "dismiss", "go away", "hide", "shukriya", "dhanyavad", "धन्यवाद", "शुक्रिया"
        )

        private val SCREEN_ACTIONS = setOf(
            "tap", "tap_xy", "long_press", "scroll", "click", "type_text", "go_back", "go_home",
            "recents", "notifications", "open_app"
        )

        private val FILLER_WORDS = setOf(
            "on", "the", "this", "that", "pe", "par", "ko", "ka", "ke", "mein", "me",
            "का", "को", "के", "पर", "में", "the", "a", "an", "button", "बटन"
        )
    }

    private var pendingConfirmation: Pair<GeminiAction, Long>? = null

    // A task paused because the AI asked the user something (e.g. "which video?")
    private data class PendingTask(val originalQuery: String, val question: String, val at: Long)
    private var pendingTask: PendingTask? = null

    // Item 17: Normalize text including Devanagari punctuation (।, ॥)
    fun normalizeText(text: String): String {
        return text.lowercase()
            .replace("।", " ")
            .replace("॥", " ")
            .replace(Regex("[\\p{Punct}&&[^@]]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    // Token / Word-boundary matching (Item 11)
    fun containsWord(text: String, word: String): Boolean {
        val normalized = normalizeText(text)
        val target = normalizeText(word)
        if (target.isBlank()) return false

        // For ASCII words use \b boundary; for Devanagari or unicode use token split
        val tokens = normalized.split(" ")
        val targetTokens = target.split(" ")

        if (targetTokens.size == 1) {
            return tokens.contains(target)
        }

        // Multi-word sequence match
        for (i in 0..tokens.size - targetTokens.size) {
            if (tokens.subList(i, i + targetTokens.size) == targetTokens) {
                return true
            }
        }
        return false
    }

    private fun compact(text: String): String = normalizeText(text).replace(" ", "")

    // "hey tech chat" / "hey techchat" / "Hey TechChat," all count
    fun isWakeWord(query: String): Boolean {
        val squashed = compact(query)
        if (squashed.isBlank()) return false
        val candidates = (WAKE_VARIANTS + prefsManager.wakeWord)
            .map { compact(it) }
            .filter { it.isNotBlank() }
        return candidates.any { squashed.contains(it) }
    }

    // Returns what was said AFTER the wake word (Item 7)
    fun stripWakeWord(query: String): String {
        val wakes = (WAKE_VARIANTS + prefsManager.wakeWord).sortedByDescending { it.length }
        for (w in wakes) {
            val chars = w.filter { !it.isWhitespace() }
            if (chars.isBlank()) continue
            val pattern = Regex(
                chars.map { Regex.escape(it.toString()) }.joinToString("\\s*"),
                RegexOption.IGNORE_CASE
            )
            val m = pattern.find(query) ?: continue
            return query.substring(m.range.last + 1).trim().trimStart(',', '.', ':', ';', '!', ' ')
        }
        return query.trim()
    }

    // Fast-path execution for high-confidence local commands
    fun tryExecuteFastPath(query: String): ExecutionResult? {
        val normalized = normalizeText(query)

        // 0. Check pending confirmation for AI actions (Item 16)
        val pending = pendingConfirmation
        if (pending != null) {
            val (action, timestamp) = pending
            if (System.currentTimeMillis() - timestamp < 10_000L) {
                if (containsWord(normalized, "yes") || containsWord(normalized, "haan") ||
                    containsWord(normalized, "हाँ") || containsWord(normalized, "sure") ||
                    containsWord(normalized, "yep") || containsWord(normalized, "ok")
                ) {
                    pendingConfirmation = null
                    return executeConfirmedAction(action)
                } else if (containsWord(normalized, "no") || containsWord(normalized, "nahin") ||
                    containsWord(normalized, "नहीं") || containsWord(normalized, "cancel") ||
                    containsWord(normalized, "stop")
                ) {
                    pendingConfirmation = null
                    return ExecutionResult(true, "Action cancelled.", isSystemAction = true)
                }
            } else {
                pendingConfirmation = null
            }
        }

        // 0b. Dismiss the hologram
        if (normalized in DISMISS_PHRASES ||
            containsWord(normalized, "hide hologram") ||
            containsWord(normalized, "hologram hatao")
        ) {
            return ExecutionResult(true, "At your service, sir.", isSystemAction = true, dismissHologram = true)
        }

        // 1. Show Hologram Face
        if (containsWord(normalized, "apna face dikhao") ||
            containsWord(normalized, "show face") ||
            containsWord(normalized, "show hologram") ||
            containsWord(normalized, "hologram wapas") ||
            containsWord(normalized, "hologram dikhao") ||
            containsWord(normalized, "अपना चेहरा दिखाओ") ||
            containsWord(normalized, "होलोग्राम दिखाओ")
        ) {
            return ExecutionResult(
                success = true,
                spokenResponse = "Right here, sir.",
                isSystemAction = true,
                showHologramFace = true
            )
        }

        // 2. Open YouTube (Exact word matching)
        if (containsWord(normalized, "open youtube") ||
            containsWord(normalized, "youtube kholo") ||
            containsWord(normalized, "यूट्यूब खोलो") ||
            containsWord(normalized, "यूट्यूब ओपन करो")
        ) {
            val opened = launchAppByPackageOrIntent("com.google.android.youtube", "https://www.youtube.com")
            return if (opened) {
                ExecutionResult(true, "Opening YouTube, sir.", isSystemAction = true)
            } else {
                ExecutionResult(false, "Could not open YouTube on this device.", isSystemAction = true)
            }
        }

        // 3. Home / Close App (Item 13: Strict entire command only, do not trigger on 'torch band karo')
        val isEntireCloseApp = normalized == "close app" ||
            normalized == "close this" ||
            normalized == "go home" ||
            normalized == "home jao" ||
            normalized == "home जाओ" ||
            normalized == "band karo" ||
            normalized == "बंद करो" ||
            normalized == "app band karo" ||
            normalized == "ऐप बंद करो" ||
            normalized == "youtube band karo" ||
            normalized == "यूट्यूब बंद करो"

        if (isEntireCloseApp) {
            val closed = TechChatAccessibilityService.instance?.goHome() ?: false
            if (!closed) {
                try {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(homeIntent)
                } catch (e: Exception) {
                    Log.w(TAG, "Home intent fallback failed", e)
                }
            }
            return ExecutionResult(true, "Going to the home screen.", isSystemAction = true)
        }

        // 4. WhatsApp Intent (Item 14: Parser stripping verbs and filler)
        val hasWhatsAppWord = containsWord(normalized, "whatsapp") || containsWord(normalized, "व्हाट्सएप")
        val hasSendIntent = containsWord(normalized, "send") || containsWord(normalized, "bhejo") ||
            containsWord(normalized, "message") || containsWord(normalized, "भेजो") || containsWord(normalized, "मैसेज")

        if (hasWhatsAppWord && hasSendIntent) {
            val (contact, messageText) = parseWhatsAppCommand(query)
            if (!isWhatsAppInstalled()) {
                return ExecutionResult(false, "WhatsApp is not installed on this device.", isSystemAction = true)
            }

            val launched = sendWhatsAppMessage(messageText)
            return if (launched) {
                if (messageText.isNotBlank()) {
                    val spoken = if (contact.isNotBlank()) {
                        "Opening WhatsApp to send '$messageText' to $contact."
                    } else {
                        "Opening WhatsApp to send your message: $messageText"
                    }
                    ExecutionResult(true, spoken, isSystemAction = true)
                } else {
                    ExecutionResult(true, "Opening WhatsApp draft. What message would you like to send?", isSystemAction = true)
                }
            } else {
                ExecutionResult(false, "Failed to launch WhatsApp.", isSystemAction = true)
            }
        }

        // 5. Button Click (Item 12)
        val isClickWord = containsWord(normalized, "click") || containsWord(normalized, "dabao") ||
            containsWord(normalized, "press") || containsWord(normalized, "दबाओ") || containsWord(normalized, "क्लिक")
        val hasButtonWord = containsWord(normalized, "button") || containsWord(normalized, "बटन")

        if (isClickWord && hasButtonWord) {
            // Check if user asked for color
            val hasColorWord = containsWord(normalized, "red") || containsWord(normalized, "लाल") ||
                containsWord(normalized, "blue") || containsWord(normalized, "नीला") ||
                containsWord(normalized, "green") || containsWord(normalized, "हरा")

            if (hasColorWord) {
                return ExecutionResult(
                    success = false,
                    spokenResponse = "Color-based clicking is not supported. Please tell me the button label.",
                    isSystemAction = true
                )
            }

            val target = extractButtonTarget(query)
            if (target.isBlank()) {
                return ExecutionResult(false, "Please specify which button label to click.", isSystemAction = true)
            }

            val clicked = TechChatAccessibilityService.instance?.clickProminentActionButton(target) == true ||
                TechChatAccessibilityService.instance?.clickNodeWithText(target) == true

            return if (clicked) {
                ExecutionResult(true, "Clicked $target button.", isSystemAction = true)
            } else {
                val accActive = TechChatAccessibilityService.instance != null
                val msg = if (!accActive) {
                    "Accessibility Service is not enabled. Please enable it in Settings to allow screen clicking."
                } else {
                    "Could not find '$target' button on screen."
                }
                ExecutionResult(false, msg, isSystemAction = true)
            }
        }

        return null
    }

    // Item 14: WhatsApp Parser
    fun parseWhatsAppCommand(query: String): Pair<String, String> {
        var clean = query.trim()

        // Extract contact if given (e.g. "to Mom", "Rohan ko")
        var contact = ""
        val contactMatch = Regex("(?i)(?:to|ko|को)\\s+([a-zA-Z\\u0900-\\u097F]+)").find(clean)
        if (contactMatch != null && contactMatch.groupValues.size > 1) {
            val potentialContact = contactMatch.groupValues[1].trim()
            if (!potentialContact.equals("whatsapp", ignoreCase = true)) {
                contact = potentialContact
                clean = clean.replace(contactMatch.value, " ")
            }
        }

        // Remove trigger words from sentence
        val wordsToRemove = listOf(
            "whatsapp", "व्हाट्सएप", "send", "message", "bhejo", "भेजो", "karo", "करो",
            "pe", "par", "me", "mein", "पर", "में", "via", "on", "draft"
        )

        var tokens = clean.split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
        tokens.removeAll { t ->
            val norm = normalizeText(t)
            wordsToRemove.contains(norm)
        }

        val message = tokens.joinToString(" ").trim()
        return Pair(contact, message)
    }

    // Item 12: Extract button target supporting both word orders and skipping filler
    fun extractButtonTarget(query: String): String {
        var text = normalizeText(query)

        // Strip triggers
        text = text.replace("click", " ")
            .replace("dabao", " ")
            .replace("press", " ")
            .replace("दबाओ", " ")
            .replace("क्लिक", " ")
            .replace("karo", " ")
            .replace("करो", " ")

        val tokens = text.split(" ").filter { it.isNotBlank() && !FILLER_WORDS.contains(it) }
        return tokens.joinToString(" ").trim()
    }

    private suspend fun captureScreenContext(): String? {
        if (!prefsManager.isShareScreenEnabled) return null
        val svc = TechChatAccessibilityService.instance ?: return null
        return withContext(Dispatchers.Default) { svc.captureScreenElements() }
    }

    // Hides the hologram for a moment so it is not in the screenshot, then grabs the frame
    private suspend fun captureScreenshot(): String? {
        if (!ScreenCaptureService.isActive.value) return null
        val hook = TechChatOverlayService.hologramVisibilityHook
        hook?.invoke(false)
        try {
            if (hook != null) delay(260)
            return ScreenCaptureService.captureJpegBase64()
        } finally {
            hook?.invoke(true)
        }
    }

    fun planToSpeech(steps: List<String>): String {
        val body = steps.take(8).mapIndexed { i, step -> "Step ${i + 1}, $step" }.joinToString(". ")
        return "Here is my plan. $body."
    }

    suspend fun processWithGemini(
        query: String,
        onPlan: (suspend (List<String>) -> Unit)? = null
    ): ExecutionResult {
        val apiKey = prefsManager.geminiApiKey
        if (apiKey.isBlank()) {
            return ExecutionResult(
                success = false,
                spokenResponse = "Please configure your Gemini API Key in Settings to enable intelligence.",
                isSystemAction = false
            )
        }

        var originalQuery = query
        var prompt = query
        var step = 0

        // Resuming a task where the AI had asked the user something
        val paused = pendingTask
        pendingTask = null
        if (paused != null && System.currentTimeMillis() - paused.at < 90_000L) {
            originalQuery = paused.originalQuery
            prompt = "Original task: \"${paused.originalQuery}\". You asked the user: \"${paused.question}\". " +
                "The user answered: \"$query\". Continue the task with the next single action using the CURRENT SCREEN."
        }
        val userWords = "$originalQuery $query".lowercase()

        while (true) {
            step++
            val screenContext = captureScreenContext()
            val sensitiveScreen = screenContext?.startsWith("[Sensitive") == true
            val screenshot = if (sensitiveScreen || !prefsManager.isShareScreenEnabled) null else captureScreenshot()

            val result = geminiService.generateContent(
                apiKey = apiKey,
                prompt = prompt,
                model = prefsManager.selectedModel,
                screenContext = screenContext,
                screenshotBase64 = screenshot
            )

            val rawResponse = result.getOrNull()
                ?: return ExecutionResult(
                    success = false,
                    spokenResponse = "I encountered an error connecting to Gemini: ${result.exceptionOrNull()?.message ?: "Network error"}",
                    isSystemAction = false
                )

            val geminiAction = geminiService.parseActionResponse(rawResponse)
            val targetLabel = targetLabelOf(geminiAction)

            // Tell the user the plan first (multi-step tasks), then start executing
            if (geminiAction.plan.isNotEmpty() && onPlan != null) {
                onPlan(geminiAction.plan)
            }

            // The AI needs information from the user: pause here, the next thing the user says is the answer
            if (geminiAction.action == "ask_user") {
                pendingTask = PendingTask(originalQuery, geminiAction.speechForTts, System.currentTimeMillis())
                return ExecutionResult(
                    success = true,
                    spokenResponse = geminiAction.speechForTts,
                    isSystemAction = true,
                    awaitingUserInput = true
                )
            }

            // Safety: payment / destructive buttons the user never mentioned are blocked outright (Item 16)
            val dangerousKeyword = findDangerousKeyword(targetLabel)
            if (dangerousKeyword != null) {
                if (!userWords.contains(dangerousKeyword)) {
                    return ExecutionResult(
                        success = false,
                        spokenResponse = "Action blocked for security: automated clicking on payment or destructive buttons is prohibited.",
                        isSystemAction = true
                    )
                }
                // The user did ask for it - still confirm by voice first
                pendingConfirmation = Pair(geminiAction, System.currentTimeMillis())
                return ExecutionResult(
                    success = true,
                    spokenResponse = "Do you want me to ${describeAction(geminiAction)}? Say yes or no.",
                    isSystemAction = true,
                    awaitingConfirmation = true
                )
            }

            val exec = executeConfirmedAction(geminiAction)

            val keepGoing = geminiAction.more &&
                exec.success &&
                geminiAction.action in SCREEN_ACTIONS &&
                step < MAX_AGENT_STEPS
            if (!keepGoing) return exec

            // Give the app a moment to react, then look at the new screen and continue
            delay(1300)
            prompt = "Continue the task: \"$originalQuery\". The previous step (${geminiAction.action}) was executed. " +
                "Look at the CURRENT SCREEN and give the next single action. " +
                "If the task is complete, return action 'none' with more=false."
        }
    }

    private fun targetLabelOf(action: GeminiAction): String {
        return when (action.action) {
            "click" -> action.target.lowercase()
            "tap", "long_press" -> when {
                action.element > 0 ->
                    (TechChatAccessibilityService.instance?.elementLabel(action.element) ?: "").lowercase()
                action.target.isNotBlank() -> action.target.lowercase()
                else -> action.speech.lowercase()
            }
            // Coordinate taps have no label, so judge by what the AI says it is tapping
            "tap_xy" -> action.speech.lowercase()
            else -> ""
        }
    }

    private fun findDangerousKeyword(label: String): String? {
        if (label.isBlank()) return null
        return DANGEROUS_BUTTON_KEYWORDS.firstOrNull { keyword ->
            Regex("\\b${Regex.escape(keyword)}\\b").containsMatchIn(label)
        }
    }

    private fun describeAction(action: GeminiAction): String {
        return when (action.action) {
            "click" -> "click the '${action.target}' button"
            "tap", "long_press", "tap_xy" -> {
                val label = targetLabelOf(action).ifBlank { action.target }.ifBlank { "that spot on the screen" }
                "tap '$label'"
            }
            "type_text" -> "type '${action.text}' into the active field"
            "send_whatsapp" -> "send '${action.text}' on WhatsApp"
            else -> "perform this action"
        }
    }

    private fun executeConfirmedAction(action: GeminiAction): ExecutionResult {
        return when (action.action) {
            "open_app" -> {
                val resolvedPkg = resolveApp(action.target)
                if (resolvedPkg != null) {
                    val opened = launchAppByPackageOrIntent(resolvedPkg, "")
                    if (opened) {
                        ExecutionResult(true, action.speechForTts, isSystemAction = true)
                    } else {
                        ExecutionResult(false, "Could not launch app.", isSystemAction = true)
                    }
                } else {
                    ExecutionResult(false, "I could not find that app.", isSystemAction = true)
                }
            }

            "go_home" -> {
                TechChatAccessibilityService.instance?.goHome()
                ExecutionResult(true, "Going to the home screen.", isSystemAction = true)
            }

            "go_back" -> {
                val back = TechChatAccessibilityService.instance?.goBack() ?: false
                if (back) {
                    ExecutionResult(true, action.speechForTts, isSystemAction = true)
                } else {
                    ExecutionResult(false, "Accessibility Service is not enabled to navigate back.", isSystemAction = true)
                }
            }

            "click" -> {
                val target = action.target.ifBlank { "send" }
                val clicked = TechChatAccessibilityService.instance?.clickProminentActionButton(target) == true ||
                    TechChatAccessibilityService.instance?.clickNodeWithText(target) == true
                if (clicked) {
                    ExecutionResult(true, action.speechForTts, isSystemAction = true)
                } else {
                    ExecutionResult(false, "Could not find button '$target' on screen.", isSystemAction = true)
                }
            }

            "tap" -> withAccessibility(action, "I could not find that on the screen.") { svc ->
                when {
                    action.element > 0 -> svc.tapElement(action.element)
                    action.x >= 0f && action.y >= 0f -> svc.tapNormalized(action.x, action.y)
                    action.target.isNotBlank() ->
                        svc.clickProminentActionButton(action.target) || svc.clickNodeWithText(action.target)
                    else -> false
                }
            }

            "tap_xy" -> withAccessibility(action, "I could not tap there.") { svc ->
                action.x >= 0f && action.y >= 0f && svc.tapNormalized(action.x, action.y)
            }

            "long_press" -> withAccessibility(action, "I could not long press that.") { svc ->
                when {
                    action.element > 0 -> svc.longPressElement(action.element)
                    action.x >= 0f && action.y >= 0f -> svc.longPressNormalized(action.x, action.y)
                    else -> false
                }
            }

            "scroll" -> withAccessibility(action, "I could not scroll.") { svc ->
                svc.scroll(action.direction)
            }

            "recents" -> withAccessibility(action, "I could not open recent apps.") { svc -> svc.openRecents() }

            "notifications" -> withAccessibility(action, "I could not open notifications.") { svc ->
                svc.openNotifications()
            }

            "type_text" -> {
                val typed = TechChatAccessibilityService.instance?.typeTextIntoFocused(action.text) ?: false
                if (typed) {
                    ExecutionResult(true, action.speechForTts, isSystemAction = true)
                } else {
                    ExecutionResult(false, "No active text field found on screen to type into.", isSystemAction = true)
                }
            }

            "send_whatsapp" -> {
                if (!isWhatsAppInstalled()) {
                    ExecutionResult(false, "WhatsApp is not installed on this device.", isSystemAction = true)
                } else {
                    val sent = sendWhatsAppMessage(action.text)
                    if (sent) {
                        ExecutionResult(true, action.speechForTts, isSystemAction = true)
                    } else {
                        ExecutionResult(false, "Failed to launch WhatsApp.", isSystemAction = true)
                    }
                }
            }

            else -> {
                ExecutionResult(
                    success = true,
                    spokenResponse = action.speechForTts,
                    isSystemAction = false
                )
            }
        }
    }

    private fun withAccessibility(
        action: GeminiAction,
        failMessage: String,
        block: (TechChatAccessibilityService) -> Boolean
    ): ExecutionResult {
        val svc = TechChatAccessibilityService.instance
            ?: return ExecutionResult(
                false,
                "Accessibility Service is not enabled. Please enable it in Settings to allow screen control.",
                isSystemAction = true
            )
        return if (block(svc)) {
            ExecutionResult(true, action.speechForTts, isSystemAction = true)
        } else {
            ExecutionResult(false, failMessage, isSystemAction = true)
        }
    }

    // Item 15: Resolve app by package or installed launcher activity matching label
    fun resolveApp(target: String): String? {
        val clean = target.trim().lowercase()
        if (clean.isBlank()) return null

        // 1. Alias map check
        APP_ALIASES[clean]?.let { return it }

        // 2. Direct package name check
        if (clean.contains(".")) {
            try {
                context.packageManager.getPackageInfo(clean, 0)
                return clean
            } catch (e: Exception) {
                // Not found
            }
        }

        // 3. Query installed launcher apps and match by label
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val pkgManager = context.packageManager
            val apps = pkgManager.queryIntentActivities(mainIntent, 0)

            // Exact label match
            for (app in apps) {
                val label = app.loadLabel(pkgManager).toString().lowercase()
                if (label == clean) {
                    return app.activityInfo.packageName
                }
            }

            // Word-boundary contains match
            for (app in apps) {
                val label = app.loadLabel(pkgManager).toString().lowercase()
                if (label.contains(clean)) {
                    return app.activityInfo.packageName
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving app label: $target", e)
        }

        return null
    }

    fun isWhatsAppInstalled(): Boolean {
        val pm = context.packageManager
        return try {
            pm.getPackageInfo("com.whatsapp", 0)
            true
        } catch (e: Exception) {
            try {
                pm.getPackageInfo("com.whatsapp.w4b", 0)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    fun sendWhatsAppMessage(message: String): Boolean {
        // Item 14: Use whatsapp://send?text= with package com.whatsapp and com.whatsapp.w4b
        val encoded = Uri.encode(message)
        val uri = if (message.isNotBlank()) {
            Uri.parse("whatsapp://send?text=$encoded")
        } else {
            Uri.parse("whatsapp://send")
        }

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            setPackage("com.whatsapp")
        }

        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // Try WhatsApp Business fallback
            try {
                intent.setPackage("com.whatsapp.w4b")
                context.startActivity(intent)
                true
            } catch (e2: Exception) {
                // Fallback to wa.me if installed
                if (isWhatsAppInstalled()) {
                    try {
                        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=$encoded")).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(webIntent)
                        true
                    } catch (e3: Exception) {
                        false
                    }
                } else {
                    false
                }
            }
        }
    }

    fun launchAppByPackageOrIntent(packageName: String, fallbackUrl: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else if (fallbackUrl.isNotBlank()) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app: $packageName", e)
            false
        }
    }
}
