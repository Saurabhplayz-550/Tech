package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.data.PreferencesManager
import com.example.service.ScreenCaptureService
import com.example.service.TechChatAccessibilityService
import com.example.service.TechChatOverlayService
import com.example.ui.screens.MainScreen
import com.example.ui.theme.TechChatTheme
import com.example.ui.viewmodel.AssistantViewModel

class MainActivity : ComponentActivity() {

    private val assistantViewModel: AssistantViewModel by viewModels()

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            assistantViewModel.speak("Microphone permission granted. Voice sensors online.")
        }
    }

    private var projectionAsked = false

    // One-time "start recording/casting" approval: lets the AI take a screenshot when you give a command
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_CODE, result.resultCode)
                .putExtra(ScreenCaptureService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, intent)
        }
    }

    override fun onResume() {
        super.onResume()
        assistantViewModel.onResume()
        runSetupStep()
        startAssistantIfNeeded()
    }

    // Walks the user through the 3 one-time settings pages (one per app open/return), phone-friendly.
    private fun runSetupStep() {
        val prefs = PreferencesManager(this)
        val micGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!micGranted) return

        try {
            if (!Settings.canDrawOverlays(this) && !prefs.wasPrompted("overlay")) {
                prefs.markPrompted("overlay")
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            if (!TechChatAccessibilityService.isServiceActive.value && !prefs.wasPrompted("accessibility")) {
                prefs.markPrompted("accessibility")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return
            }
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName) && !prefs.wasPrompted("battery")) {
                prefs.markPrompted("battery")
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
                return
            }
            if (!ScreenCaptureService.isActive.value && !projectionAsked) {
                projectionAsked = true
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(manager.createScreenCaptureIntent())
            }
        } catch (e: Exception) {
            // Some phones do not have these screens; the Settings dialog still has the manual toggles
        }
    }

    // Start the always-on "Hey TechChat" listener once permissions are in place
    private fun startAssistantIfNeeded() {
        try {
            val prefs = PreferencesManager(this)
            val micGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (prefs.isOverlayEnabled && micGranted && Settings.canDrawOverlays(this) &&
                !TechChatOverlayService.isRunning
            ) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, TechChatOverlayService::class.java).apply {
                        action = TechChatOverlayService.ACTION_START
                    }
                )
            }
        } catch (e: Exception) {
            // ignore; user can still toggle manually
        }
    }

    override fun onPause() {
        super.onPause()
        assistantViewModel.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check microphone permission on launch
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            TechChatTheme {
                MainScreen(
                    viewModel = assistantViewModel,
                    onRequestMicPermission = {
                        requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                )
            }
        }
    }
}
