package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.TechChatAccessibilityService
import com.example.ui.hologram.BlueHologramCore
import com.example.ui.theme.TechBlack
import com.example.ui.theme.TechCard
import com.example.ui.theme.TechCyan
import com.example.ui.theme.TechCyanBright
import com.example.ui.theme.TechDeepBlue
import com.example.ui.theme.TechElectricBlue
import com.example.ui.theme.TechError
import com.example.ui.theme.TechSuccess
import com.example.ui.theme.TechSurface
import com.example.ui.theme.TechSurfaceVariant
import com.example.ui.theme.TechTextMuted
import com.example.ui.theme.TechTextPrimary
import com.example.ui.theme.TechTextSecondary
import com.example.ui.viewmodel.AssistantStatus
import com.example.ui.viewmodel.AssistantViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: AssistantViewModel,
    onRequestMicPermission: () -> Unit
) {
    val status by viewModel.status.collectAsState()
    val spokenText by viewModel.spokenText.collectAsState()
    val aiResponse by viewModel.aiResponse.collectAsState()
    val amplitude by viewModel.audioAmplitude.collectAsState()
    val commandLogs by viewModel.commandLogs.collectAsState()
    val isOverlayRunning by viewModel.isOverlayRunning.collectAsState()
    val isAccessibilityActive by TechChatAccessibilityService.isServiceActive.collectAsState()

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }
    var typedText by remember { mutableStateOf("") }

    val keyboardController = LocalSoftwareKeyboardController.current

    val onSendCommand: (String) -> Unit = { command ->
        if (command.isNotBlank()) {
            viewModel.processUserCommand(command.trim())
            typedText = ""
            keyboardController?.hide()
        }
    }

    // Pulse animation for listening state
    val infiniteTransition = rememberInfiniteTransition(label = "MicPulse")
    val micPulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "MicScale"
    )

    Scaffold(
        containerColor = TechBlack,
        topBar = {
            // Sci-Fi Cockpit Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Brand HUD
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (status == AssistantStatus.LISTENING) TechSuccess else TechCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "TECHCHAT AI",
                            color = TechCyanBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = "HOLOGRAPHIC CORE v2.5",
                            color = TechTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                }

                // Status Chips & Top Action Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Accessibility status dot
                    Surface(
                        color = TechSurfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.border(
                            1.dp,
                            if (isAccessibilityActive) TechSuccess.copy(alpha = 0.5f) else TechCyan.copy(alpha = 0.3f),
                            RoundedCornerShape(16.dp)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isAccessibilityActive) TechSuccess else TechError)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isAccessibilityActive) "ACC: ON" else "ACC: OFF",
                                color = TechTextSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // History Button
                    IconButton(
                        onClick = { showHistorySheet = true },
                        modifier = Modifier
                            .size(38.dp)
                            .background(TechSurfaceVariant, CircleShape)
                            .border(1.dp, TechCyan.copy(alpha = 0.35f), CircleShape)
                            .testTag("history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Chat History",
                            tint = TechCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Right Corner Setting Button
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier
                            .size(38.dp)
                            .background(TechSurfaceVariant, CircleShape)
                            .border(1.dp, TechCyan.copy(alpha = 0.4f), CircleShape)
                            .testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TechCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .background(TechBlack),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main Center Area: Animated Blue Hologram Core!
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                // Central Glowing Blue Hologram (auto-rotating + 3D finger drag)
                BlueHologramCore(
                    modifier = Modifier
                        .clickable { viewModel.toggleListening() }
                        .testTag("blue_hologram_core"),
                    coreSize = 310.dp,
                    isListening = status == AssistantStatus.LISTENING,
                    isSpeaking = status == AssistantStatus.SPEAKING,
                    audioAmplitude = amplitude,
                    onClick = { viewModel.toggleListening() }
                )

                // Status Overlay HUD
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val statusText = when (status) {
                        AssistantStatus.IDLE -> "DRAG TO ROTATE 3D • TYPE OR SPEAK"
                        AssistantStatus.LISTENING -> "LISTENING TO VOICE INPUT..."
                        AssistantStatus.THINKING -> "GEMINI PROCESSING..."
                        AssistantStatus.SPEAKING -> "TRANSMITTING RESPONSE..."
                        AssistantStatus.EXECUTING -> "EXECUTING SYSTEM ACTION..."
                    }

                    val statusColor = when (status) {
                        AssistantStatus.IDLE -> TechCyan.copy(alpha = 0.75f)
                        AssistantStatus.LISTENING -> TechSuccess
                        AssistantStatus.THINKING -> TechCyanBright
                        AssistantStatus.SPEAKING -> TechElectricBlue
                        AssistantStatus.EXECUTING -> Color(0xFFFFD600)
                    }

                    Text(
                        text = statusText,
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    if (spokenText.isNotBlank() && status == AssistantStatus.LISTENING) {
                        Text(
                            text = "\"$spokenText\"",
                            color = TechTextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .padding(horizontal = 24.dp)
                                .padding(top = 2.dp),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Lower HUD: AI Output Terminal, Quick Actions & Typing Input
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // AI Output Terminal Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = TechSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, TechCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.SmartToy,
                                    contentDescription = null,
                                    tint = TechCyan,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "AI OUTPUT TERMINAL",
                                    color = TechCyanBright,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                            }

                            if (status == AssistantStatus.SPEAKING) {
                                IconButton(
                                    onClick = { viewModel.stopSpeaking() },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = "Stop Speaking",
                                        tint = TechCyan,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = aiResponse,
                            color = TechTextPrimary,
                            fontSize = 12.5.sp,
                            lineHeight = 17.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Command Simulator Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    val quickCommands = listOf(
                        "YouTube Kholo" to "Open YouTube App",
                        "YouTube Band Karo" to "Close YouTube and Go Home",
                        "WhatsApp Hello" to "Send message via WhatsApp",
                        "Click Red Button" to "Click prominent action button",
                        "Apna Face Dikhao" to "Display full hologram core",
                        "Who are you?" to "Introduce TechChat AI"
                    )

                    items(quickCommands) { (label, _) ->
                        Surface(
                            color = TechCard,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .border(1.dp, TechElectricBlue.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                .clickable {
                                    onSendCommand(label)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = TechCyan,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = label,
                                    color = TechTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // TYPING INPUT BAR (Interactive text command field)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = typedText,
                        onValueChange = { typedText = it },
                        placeholder = {
                            Text(
                                "Type order (e.g. YouTube kholo, ask AI...)",
                                color = TechTextMuted,
                                fontSize = 12.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Terminal",
                                tint = TechCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (typedText.isNotBlank()) {
                                IconButton(onClick = { typedText = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = TechTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        maxLines = 1,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSendCommand(typedText) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TechTextPrimary,
                            unfocusedTextColor = TechTextPrimary,
                            focusedBorderColor = TechCyan,
                            unfocusedBorderColor = TechCyan.copy(alpha = 0.35f),
                            focusedContainerColor = TechSurfaceVariant,
                            unfocusedContainerColor = TechSurfaceVariant,
                            cursorColor = TechCyan
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_text_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Send Button for Typed Text
                    IconButton(
                        onClick = { onSendCommand(typedText) },
                        enabled = typedText.isNotBlank(),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (typedText.isNotBlank()) TechCyan else TechCard)
                            .border(
                                1.dp,
                                if (typedText.isNotBlank()) TechCyanBright else TechCyan.copy(alpha = 0.25f),
                                CircleShape
                            )
                            .testTag("send_typed_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (typedText.isNotBlank()) TechBlack else TechTextMuted,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }

                // Bottom Action Bar: Floating Overlay Toggle & Voice Microphone Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Floating Overlay Button
                    IconButton(
                        onClick = { viewModel.toggleOverlayService() },
                        modifier = Modifier
                            .size(46.dp)
                            .background(TechSurfaceVariant, CircleShape)
                            .border(
                                1.dp,
                                if (isOverlayRunning) TechSuccess.copy(alpha = 0.6f) else TechCyan.copy(alpha = 0.3f),
                                CircleShape
                            )
                            .testTag("floating_overlay_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Toggle Floating Overlay",
                            tint = if (isOverlayRunning) TechSuccess else TechTextMuted,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Main Voice Microphone Trigger Button
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .scale(if (status == AssistantStatus.LISTENING) micPulseScale else 1f)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        if (status == AssistantStatus.LISTENING) TechSuccess else TechCyan,
                                        TechDeepBlue
                                    )
                                )
                            )
                            .clickable {
                                viewModel.toggleListening()
                            }
                            .testTag("microphone_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (status == AssistantStatus.LISTENING) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = TechBlack,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Settings Button
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier
                            .size(46.dp)
                            .background(TechSurfaceVariant, CircleShape)
                            .border(1.dp, TechCyan.copy(alpha = 0.3f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TechCyanBright,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }

    // Settings Bottom Sheet
    if (showSettingsSheet) {
        SettingsBottomSheet(
            prefsManager = viewModel.prefsManager,
            onDismiss = { showSettingsSheet = false },
            onRequestMicPermission = onRequestMicPermission
        )
    }

    // Chat History Bottom Sheet
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = TechSurface,
            dragHandle = null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CONVERSATION & COMMAND LOGS",
                        color = TechCyanBright,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = { showHistorySheet = false }) {
                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = TechTextSecondary)
                    }
                }

                HorizontalDivider(color = TechCyan.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                if (commandLogs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No commands executed yet.\nType or speak to start!",
                            color = TechTextMuted,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(commandLogs) { log ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = TechCard),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        1.dp,
                                        if (log.isSystemAction) TechElectricBlue.copy(alpha = 0.4f) else TechCyan.copy(alpha = 0.2f),
                                        RoundedCornerShape(10.dp)
                                    )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "USER: ${log.query}",
                                            color = TechCyanBright,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        if (log.isSystemAction) {
                                            Text(
                                                text = "[ACTION]",
                                                color = Color(0xFFFFD600),
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "AI: ${log.response}",
                                        color = TechTextPrimary,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
