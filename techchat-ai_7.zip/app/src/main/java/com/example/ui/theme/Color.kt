package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TechBlack = Color(0xFF000000)
val TechSurface = Color(0xFF060B14)
val TechSurfaceVariant = Color(0xFF0D1624)
val TechCard = Color(0xFF101C30)

val TechCyan = Color(0xFF00E5FF)
val TechCyanBright = Color(0xFF80D8FF)
val TechElectricBlue = Color(0xFF00B0FF)
val TechDeepBlue = Color(0xFF2979FF)
val TechAccentGlow = Color(0xFF00E5FF)

val TechTextPrimary = Color(0xFFE0F7FA)
val TechTextSecondary = Color(0xFF81D4FA)
val TechTextMuted = Color(0xFF546E7A)

val TechSuccess = Color(0xFF00E676)
val TechWarning = Color(0xFFFFD600)
val TechError = Color(0xFFFF5252)
