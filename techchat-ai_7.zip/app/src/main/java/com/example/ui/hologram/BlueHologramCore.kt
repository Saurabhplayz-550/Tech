package com.example.ui.hologram

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

// 3D Point with full 3-axis rotation and perspective projection
data class Point3D(val x: Float, val y: Float, val z: Float) {
    fun rotateX(angle: Float): Point3D {
        val cosA = cos(angle)
        val sinA = sin(angle)
        return Point3D(x, y * cosA - z * sinA, y * sinA + z * cosA)
    }

    fun rotateY(angle: Float): Point3D {
        val cosA = cos(angle)
        val sinA = sin(angle)
        return Point3D(x * cosA + z * sinA, y, -x * sinA + z * cosA)
    }

    fun rotateZ(angle: Float): Point3D {
        val cosA = cos(angle)
        val sinA = sin(angle)
        return Point3D(x * cosA - y * sinA, x * sinA + y * cosA, z)
    }

    fun project(centerX: Float, centerY: Float, fov: Float = 550f): Offset {
        val distance = fov + z
        val scale = if (distance > 1f) fov / distance else 1f
        return Offset(centerX + x * scale, centerY + y * scale)
    }
}

// Outward warp / radial energy beam
data class RadialStreak(
    val angle: Float,
    val distanceRatio: Float,
    val length: Float,
    val width: Float,
    val speed: Float,
    val alpha: Float
)

// Constellation particle on the sphere
data class SphereParticle(
    val basePoint: Point3D,
    val size: Float,
    val pulsePhase: Float,
    val isBright: Boolean
)

@Composable
fun BlueHologramCore(
    modifier: Modifier = Modifier,
    coreSize: Dp = 340.dp,
    isListening: Boolean = false,
    isSpeaking: Boolean = false,
    audioAmplitude: Float = 0f,
    onClick: () -> Unit = {},
    onDragWindow: ((dx: Float, dy: Float) -> Unit)? = null
) {
    // Continuous breathing pulse animation
    val infiniteTransition = rememberInfiniteTransition(label = "HologramPulse")

    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingScale"
    )

    val coreFlicker by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CoreFlicker"
    )

    // Interactive 3D Rotation Angles (Driven by both Auto-Rotation and Finger Drag)
    var angleX by remember { mutableFloatStateOf(0.18f) }
    var angleY by remember { mutableFloatStateOf(0f) }
    var angleZ by remember { mutableFloatStateOf(0.06f) }

    // User interaction tracking
    var isUserInteracting by remember { mutableStateOf(false) }
    var velocityX by remember { mutableFloatStateOf(0f) }
    var velocityY by remember { mutableFloatStateOf(0f) }

    // Frame-by-frame loop for continuous smooth auto-rotation and finger drag inertia
    LaunchedEffect(Unit) {
        var lastTimeNanos = 0L
        while (true) {
            withFrameNanos { frameTimeNanos ->
                if (lastTimeNanos != 0L) {
                    val dt = ((frameTimeNanos - lastTimeNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)

                    if (!isUserInteracting) {
                        // Base auto-rotation speeds (Y-axis spin, subtle X and Z orbital wobbles)
                        val baseSpeedY = 0.32f
                        val baseSpeedX = 0.08f

                        // Apply inertia if user flicked with finger
                        angleY += (baseSpeedY + velocityY) * dt
                        angleX += (baseSpeedX + velocityX) * dt
                        angleZ += 0.04f * dt

                        // Dampen velocity over time back to default cruise speed
                        velocityY *= (1f - dt * 2.2f).coerceAtLeast(0f)
                        velocityX *= (1f - dt * 2.2f).coerceAtLeast(0f)
                    }
                }
                lastTimeNanos = frameTimeNanos
            }
        }
    }

    // Pre-calculated Fibonacci Sphere Point Cloud (Constellation nodes)
    val sphereParticles = remember {
        val count = 280
        val rand = Random(1337)
        val goldenRatio = (1.0 + sqrt(5.0)) / 2.0
        List(count) { i ->
            val theta = (2 * PI * i / goldenRatio).toFloat()
            val phi = kotlin.math.acos(1f - 2f * (i + 0.5f) / count)

            // Add slight radial variation for 3D depth
            val r = 0.88f + rand.nextFloat() * 0.16f
            val x = (r * sin(phi) * cos(theta))
            val y = (r * cos(phi))
            val z = (r * sin(phi) * sin(theta))

            SphereParticle(
                basePoint = Point3D(x, y, z),
                size = 1.6f + rand.nextFloat() * 2.8f,
                pulsePhase = rand.nextFloat() * 2f * PI.toFloat(),
                isBright = rand.nextFloat() > 0.65f
            )
        }
    }

    // Constellation wireframe connections (nearby point pairs)
    val constellationEdges = remember {
        val edges = mutableListOf<Pair<Int, Int>>()
        for (i in 0 until 180 step 2) {
            val p1 = sphereParticles[i].basePoint
            for (j in i + 1 until (i + 14).coerceAtMost(sphereParticles.size)) {
                val p2 = sphereParticles[j].basePoint
                val dx = p1.x - p2.x
                val dy = p1.y - p2.y
                val dz = p1.z - p2.z
                val dist = sqrt(dx * dx + dy * dy + dz * dz)
                if (dist in 0.14f..0.34f && edges.size < 190) {
                    edges.add(i to j)
                }
            }
        }
        edges
    }

    // Outward radial hyperspace energy streaks (matching reference image)
    val radialStreaks = remember {
        val rand = Random(2026)
        List(36) {
            RadialStreak(
                angle = rand.nextFloat() * 2f * PI.toFloat(),
                distanceRatio = 1.05f + rand.nextFloat() * 0.55f,
                length = 12f + rand.nextFloat() * 24f,
                width = 2.0f + rand.nextFloat() * 3.5f,
                speed = 0.4f + rand.nextFloat() * 0.8f,
                alpha = 0.4f + rand.nextFloat() * 0.55f
            )
        }
    }

    // High-tech Neon Blue Palette matching user reference photo
    val whiteCore = Color(0xFFFFFFFF)
    val brightCyan = Color(0xFF00F5FF)
    val neonBlue = Color(0xFF00B0FF)
    val deepCyanGlow = Color(0xFF0077C2)
    val cosmicBlue = Color(0xFF001F3F)

    // Dynamic scale when user speaks or AI is active
    val amplitudeScale = if (isSpeaking || isListening) {
        (audioAmplitude * 0.22f).coerceIn(0f, 0.25f)
    } else 0f

    val totalScale = breathingScale + amplitudeScale

    Box(
        modifier = modifier
            .size(coreSize)
            .pointerInput(onClick) {
                detectTapGestures(
                    onTap = { onClick() }
                )
            }
            .pointerInput(coreSize, onDragWindow) {
                detectDragGestures(
                    onDragStart = {
                        isUserInteracting = true
                        velocityX = 0f
                        velocityY = 0f
                    },
                    onDragEnd = {
                        isUserInteracting = false
                    },
                    onDragCancel = {
                        isUserInteracting = false
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        // Overlay window repositioning
                        onDragWindow?.invoke(dragAmount.x, dragAmount.y)

                        // For larger hologram (>100dp), keep 3D inner rotation active
                        if (coreSize > 100.dp) {
                            val deltaY = dragAmount.x * 0.0075f
                            val deltaX = -dragAmount.y * 0.0075f

                            angleY += deltaY
                            angleX += deltaX

                            velocityY = dragAmount.x * 0.08f
                            velocityX = -dragAmount.y * 0.08f
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2f
            val centerY = canvasHeight / 2f
            val sphereRadius = (canvasWidth.coerceAtMost(canvasHeight) / 2f) * 0.70f * totalScale

            // 1. Ambient Volumetric Atmospheric Bloom (Deep Cyan & Neon Glow)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        brightCyan.copy(alpha = 0.32f * coreFlicker),
                        neonBlue.copy(alpha = 0.18f * coreFlicker),
                        deepCyanGlow.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = Offset(centerX, centerY),
                    radius = sphereRadius * 1.55f
                ),
                radius = sphereRadius * 1.55f,
                center = Offset(centerX, centerY)
            )

            // 2. Outward Radial Warp Streaks / Hyperspace Energy Fragments
            for (streak in radialStreaks) {
                val dist = sphereRadius * streak.distanceRatio
                val sx = centerX + dist * cos(streak.angle)
                val sy = centerY + dist * sin(streak.angle)
                val ex = centerX + (dist + streak.length) * cos(streak.angle)
                val ey = centerY + (dist + streak.length) * sin(streak.angle)

                // Neon cyan rectangular streak
                drawLine(
                    color = brightCyan.copy(alpha = streak.alpha * coreFlicker),
                    start = Offset(sx, sy),
                    end = Offset(ex, ey),
                    strokeWidth = streak.width,
                    cap = StrokeCap.Square
                )

                // Inner bright white highlight in center of streak
                drawLine(
                    color = whiteCore.copy(alpha = streak.alpha * 0.8f),
                    start = Offset(sx + (ex - sx) * 0.2f, sy + (ey - sy) * 0.2f),
                    end = Offset(ex - (ex - sx) * 0.2f, ey - (ey - sy) * 0.2f),
                    strokeWidth = streak.width * 0.45f,
                    cap = StrokeCap.Square
                )
            }

            // 3. Rotating Constellation Sphere Points & Edge Network
            // Transform 3D particles based on current finger/auto rotation angles
            val transformedParticles = sphereParticles.map { p ->
                val base = Point3D(
                    p.basePoint.x * sphereRadius,
                    p.basePoint.y * sphereRadius,
                    p.basePoint.z * sphereRadius
                )
                val rotated = base.rotateX(angleX).rotateY(angleY).rotateZ(angleZ)
                val screenPos = rotated.project(centerX, centerY)
                Triple(screenPos, rotated.z, p)
            }

            // Draw Constellation Lines (filament web inside the sphere)
            for ((idx1, idx2) in constellationEdges) {
                val (p1, z1, _) = transformedParticles[idx1]
                val (p2, z2, _) = transformedParticles[idx2]
                val avgZ = (z1 + z2) / 2f
                val depthFactor = ((avgZ + sphereRadius) / (2 * sphereRadius)).coerceIn(0.12f, 0.95f)

                drawLine(
                    color = neonBlue.copy(alpha = depthFactor * 0.55f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (avgZ > 0) 1.4f else 0.8f,
                    cap = StrokeCap.Round
                )
            }

            // Draw Constellation Star Nodes
            for ((pos, z, particle) in transformedParticles) {
                val depthFactor = ((z + sphereRadius) / (2 * sphereRadius)).coerceIn(0.15f, 1.0f)
                val baseAlpha = if (particle.isBright) 0.95f else 0.65f
                val nodeAlpha = (depthFactor * baseAlpha * coreFlicker).coerceIn(0.1f, 1.0f)
                val radius = particle.size * (if (z > 0) 1.25f else 0.85f)

                // Particle outer cyan glow
                drawCircle(
                    color = brightCyan.copy(alpha = nodeAlpha * 0.5f),
                    radius = radius * 2.2f,
                    center = pos
                )
                // Particle bright core
                drawCircle(
                    color = if (particle.isBright) whiteCore.copy(alpha = nodeAlpha) else brightCyan.copy(alpha = nodeAlpha),
                    radius = radius,
                    center = pos
                )
            }

            // 4. Primary Orbital Gimbal Rings (Accurately matching reference image!)
            // A. Vertical Meridian Gimbal Ring (Major vertical glowing loop)
            drawGimbalRing3D(
                centerX = centerX,
                centerY = centerY,
                radius = sphereRadius * 0.98f,
                normal = Point3D(1f, 0f, 0f), // Ring in Y-Z plane
                rotX = angleX,
                rotY = angleY,
                rotZ = angleZ,
                primaryColor = brightCyan,
                glowColor = neonBlue,
                hasDataTicks = true,
                doubleTrack = true
            )

            // B. Horizontal Equatorial Gimbal Ring (Major horizontal cutting loop)
            drawGimbalRing3D(
                centerX = centerX,
                centerY = centerY,
                radius = sphereRadius * 0.96f,
                normal = Point3D(0f, 1f, 0f), // Ring in X-Z plane
                rotX = angleX,
                rotY = angleY,
                rotZ = angleZ,
                primaryColor = brightCyan,
                glowColor = neonBlue,
                hasDataTicks = true,
                doubleTrack = true
            )

            // C. Diagonal 45-degree Gimbal Ring (Connecting orbital cage)
            drawGimbalRing3D(
                centerX = centerX,
                centerY = centerY,
                radius = sphereRadius * 0.92f,
                normal = Point3D(0.707f, 0.707f, 0f),
                rotX = angleX,
                rotY = angleY,
                rotZ = angleZ,
                primaryColor = neonBlue,
                glowColor = brightCyan,
                hasDataTicks = false,
                doubleTrack = false
            )

            // D. Outer Spherical Horizon Halo Ring (Great circle silhouette)
            drawCircle(
                color = brightCyan.copy(alpha = 0.45f * coreFlicker),
                radius = sphereRadius,
                center = Offset(centerX, centerY),
                style = Stroke(
                    width = 2.4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 10f, 6f, 10f))
                )
            )
            drawCircle(
                color = neonBlue.copy(alpha = 0.25f),
                radius = sphereRadius * 1.02f,
                center = Offset(centerX, centerY),
                style = Stroke(width = 1.2f)
            )

            // E. Inner Core Orbit Ring (Surrounding the central star)
            drawGimbalRing3D(
                centerX = centerX,
                centerY = centerY,
                radius = sphereRadius * 0.38f,
                normal = Point3D(0.3f, 1f, 0.2f),
                rotX = angleX * 1.2f,
                rotY = angleY * 1.4f,
                rotZ = angleZ,
                primaryColor = whiteCore,
                glowColor = brightCyan,
                hasDataTicks = false,
                doubleTrack = false
            )

            // 5. Intense Central White-Hot Energy Star (Ultron / Jarvis Core)
            val coreRadius = sphereRadius * 0.24f * coreFlicker

            // Core Radial Bloom Corona
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        whiteCore.copy(alpha = 0.98f),
                        brightCyan.copy(alpha = 0.88f),
                        neonBlue.copy(alpha = 0.55f),
                        deepCyanGlow.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = Offset(centerX, centerY),
                    radius = coreRadius
                ),
                radius = coreRadius,
                center = Offset(centerX, centerY)
            )

            // Dense White Hot Center
            drawCircle(
                color = whiteCore,
                radius = coreRadius * 0.45f,
                center = Offset(centerX, centerY)
            )

            // Concentric Mini Shockwaves
            drawCircle(
                color = brightCyan.copy(alpha = 0.75f * coreFlicker),
                radius = coreRadius * 0.72f,
                center = Offset(centerX, centerY),
                style = Stroke(width = 1.8f)
            )

            drawCircle(
                color = whiteCore.copy(alpha = 0.65f),
                radius = coreRadius * 1.15f,
                center = Offset(centerX, centerY),
                style = Stroke(width = 1.2f)
            )

            // Horizontal & Vertical Lens Flare Rays
            val rayLength = sphereRadius * 0.75f
            drawLine(
                color = whiteCore.copy(alpha = 0.85f * coreFlicker),
                start = Offset(centerX - rayLength, centerY),
                end = Offset(centerX + rayLength, centerY),
                strokeWidth = 2.2f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = brightCyan.copy(alpha = 0.65f * coreFlicker),
                start = Offset(centerX - rayLength * 1.3f, centerY),
                end = Offset(centerX + rayLength * 1.3f, centerY),
                strokeWidth = 1.0f
            )
            drawLine(
                color = whiteCore.copy(alpha = 0.85f * coreFlicker),
                start = Offset(centerX, centerY - rayLength * 0.8f),
                end = Offset(centerX, centerY + rayLength * 0.8f),
                strokeWidth = 2.0f,
                cap = StrokeCap.Round
            )
        }
    }
}

// Draw a 3D planar gimbal ring oriented perpendicular to a given normal vector
private fun DrawScope.drawGimbalRing3D(
    centerX: Float,
    centerY: Float,
    radius: Float,
    normal: Point3D,
    rotX: Float,
    rotY: Float,
    rotZ: Float,
    primaryColor: Color,
    glowColor: Color,
    hasDataTicks: Boolean,
    doubleTrack: Boolean,
    segments: Int = 64
) {
    // Determine two orthogonal basis vectors in the ring plane
    val (u, v) = computePlaneBasis(normal)

    val points = mutableListOf<Triple<Offset, Float, Float>>() // screenPos, z, angle

    for (i in 0..segments) {
        val angle = (i.toFloat() / segments) * 2 * PI.toFloat()
        val cosA = cos(angle)
        val sinA = sin(angle)

        // Point on 3D circle in ring plane
        val px = (u.x * cosA + v.x * sinA) * radius
        val py = (u.y * cosA + v.y * sinA) * radius
        val pz = (u.z * cosA + v.z * sinA) * radius

        // Rotate point with full 3-axis rotation matrix
        val rotated = Point3D(px, py, pz).rotateX(rotX).rotateY(rotY).rotateZ(rotZ)
        val screenPos = rotated.project(centerX, centerY)
        points.add(Triple(screenPos, rotated.z, angle))
    }

    // Render path segments with depth-sorted lighting
    for (i in 0 until points.size - 1) {
        val (p1, z1, angle1) = points[i]
        val (p2, z2, _) = points[i + 1]
        val avgZ = (z1 + z2) / 2f
        val depthFactor = ((avgZ + radius) / (2 * radius)).coerceIn(0.2f, 1.0f)

        // Outer glow layer
        drawLine(
            color = glowColor.copy(alpha = depthFactor * 0.42f),
            start = p1,
            end = p2,
            strokeWidth = if (avgZ > 0) 5.5f else 3.2f,
            cap = StrokeCap.Round
        )

        // Main bright track
        drawLine(
            color = primaryColor.copy(alpha = depthFactor * 0.95f),
            start = p1,
            end = p2,
            strokeWidth = if (avgZ > 0) 2.6f else 1.4f,
            cap = StrokeCap.Round
        )

        // Inner white-hot specular laser thread on front half
        if (avgZ > 0) {
            drawLine(
                color = Color.White.copy(alpha = depthFactor * 0.85f),
                start = p1,
                end = p2,
                strokeWidth = 1.1f,
                cap = StrokeCap.Round
            )
        }

        // Secondary inner parallel track if doubleTrack is enabled
        if (doubleTrack) {
            val innerScale = 0.965f
            val ip1 = Offset(centerX + (p1.x - centerX) * innerScale, centerY + (p1.y - centerY) * innerScale)
            val ip2 = Offset(centerX + (p2.x - centerX) * innerScale, centerY + (p2.y - centerY) * innerScale)
            drawLine(
                color = glowColor.copy(alpha = depthFactor * 0.65f),
                start = ip1,
                end = ip2,
                strokeWidth = 1.0f
            )
        }

        // Holographic Data Ticks along the ring
        if (hasDataTicks && i % 4 == 0) {
            val normalAngle = angle1 + (PI / 2f).toFloat()
            val tickLen = if (avgZ > 0) 5.5f else 3.5f
            val tx = p1.x + cos(normalAngle) * tickLen
            val ty = p1.y + sin(normalAngle) * tickLen

            drawLine(
                color = if (avgZ > 0) Color.White else primaryColor.copy(alpha = depthFactor),
                start = p1,
                end = Offset(tx, ty),
                strokeWidth = 1.2f
            )
        }
    }
}

// Compute two orthogonal vectors in the plane defined by normal vector
private fun computePlaneBasis(n: Point3D): Pair<Point3D, Point3D> {
    val len = sqrt(n.x * n.x + n.y * n.y + n.z * n.z)
    val norm = if (len > 0.0001f) Point3D(n.x / len, n.y / len, n.z / len) else Point3D(0f, 1f, 0f)

    // Find non-parallel vector
    val a = if (kotlin.math.abs(norm.x) < 0.9f) Point3D(1f, 0f, 0f) else Point3D(0f, 1f, 0f)

    // Cross product to get first in-plane vector u = norm x a
    val ux = norm.y * a.z - norm.z * a.y
    val uy = norm.z * a.x - norm.x * a.z
    val uz = norm.x * a.y - norm.y * a.x
    val uLen = sqrt(ux * ux + uy * uy + uz * uz)
    val u = Point3D(ux / uLen, uy / uLen, uz / uLen)

    // Second in-plane vector v = norm x u
    val vx = norm.y * u.z - norm.z * u.y
    val vy = norm.z * u.x - norm.x * u.z
    val vz = norm.x * u.y - norm.y * u.x
    val v = Point3D(vx, vy, vz)

    return Pair(u, v)
}
