package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ModelTraining
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.PreferencesManager
import com.example.service.GeminiService
import com.example.service.TechChatAccessibilityService
import com.example.service.TechChatOverlayService
import com.example.service.VoiceEngine
import com.example.ui.theme.TechBlack
import com.example.ui.theme.TechCard
import com.example.ui.theme.TechCyan
import com.example.ui.theme.TechCyanBright
import com.example.ui.theme.TechDeepBlue
import com.example.ui.theme.TechElectricBlue
import com.example.ui.theme.TechError
import com.example.ui.theme.TechSuccess
import com.example.ui.theme.TechSurface
import com.example.ui.theme.TechSurfaceVariant
import com.example.ui.theme.TechTextMuted
import com.example.ui.theme.TechTextPrimary
import com.example.ui.theme.TechTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    prefsManager: PreferencesManager,
    onDismiss: () -> Unit,
    onRequestMicPermission: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var apiKeyInput by remember { mutableStateOf(prefsManager.geminiApiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var isTestingConnection by remember { mutableStateOf(false) }

    var modelInput by remember { mutableStateOf(prefsManager.selectedModel) }
    var wakeWordInput by remember { mutableStateOf(prefsManager.wakeWord) }
    var selectedLanguage by remember { mutableStateOf(prefsManager.voiceLanguage) }
    var shareScreenContent by remember { mutableStateOf(prefsManager.isShareScreenEnabled) }
    var speechFeedback by remember { mutableStateOf(prefsManager.isSpeechFeedbackEnabled) }
    var isWakeWordRequired by remember { mutableStateOf(prefsManager.isWakeWordRequiredForOverlay) }

    // Shared StateFlow from overlay service keeps UI 100% synchronized (Item 11)
    val isOverlayActive by TechChatOverlayService.isRunningFlow.collectAsState()

    val hasMicPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val hasOverlayPermission = Settings.canDrawOverlays(context)
    val hasAccessibility = TechChatAccessibilityService.instance != null

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = TechSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TechCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CORE CONFIGURATION",
                        color = TechTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TechTextSecondary
                    )
                }
            }

            Text(
                text = "Encrypted API storage, system permissions & AI language controls",
                color = TechTextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
            )

            HorizontalDivider(color = TechCyan.copy(alpha = 0.2f))

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Gemini Brain Key Section (Encrypted Storage)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = "API Key",
                                tint = TechCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "GEMINI AI BRAIN KEY",
                                color = TechCyanBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Encrypted",
                                tint = TechSuccess,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AES-256 ENCRYPTED",
                                color = TechSuccess,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Stored securely in EncryptedSharedPreferences with header-based authorization.",
                        color = TechTextSecondary,
                        fontSize = 11.5.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_api_key_input"),
                        label = { Text("Gemini API Key") },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                Icon(
                                    imageVector = if (isApiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Visibility",
                                    tint = TechCyan
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TechCyan,
                            unfocusedBorderColor = TechCyan.copy(alpha = 0.4f),
                            focusedLabelColor = TechCyan,
                            unfocusedLabelColor = TechTextMuted,
                            cursorColor = TechCyan
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                prefsManager.geminiApiKey = apiKeyInput
                                testResult = "✓ Key saved securely in encrypted vault!"
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_api_key_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = TechBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Key", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                if (apiKeyInput.isBlank()) {
                                    testResult = "Please enter an API key first."
                                    return@OutlinedButton
                                }
                                isTestingConnection = true
                                testResult = null
                                coroutineScope.launch {
                                    val service = GeminiService()
                                    val res = service.generateContent(
                                        apiKey = apiKeyInput,
                                        prompt = "Respond with 'TechChat AI Brain online.' in one sentence.",
                                        model = modelInput.ifBlank { prefsManager.selectedModel }
                                    )
                                    isTestingConnection = false
                                    res.onSuccess {
                                        testResult = "✓ Verified: $it"
                                    }.onFailure {
                                        testResult = "✗ Failed: ${it.message}"
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_api_key_button"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TechCyanBright),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            if (isTestingConnection) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = TechCyan
                                )
                            } else {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test Brain")
                            }
                        }
                    }

                    testResult?.let { msg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = msg,
                            color = if (msg.startsWith("✓")) TechSuccess else TechError,
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Model Selection (Editable with Fallback - Item 8)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechElectricBlue.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ModelTraining,
                            contentDescription = null,
                            tint = TechCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GEMINI MODEL CONFIGURATION",
                            color = TechCyanBright,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Default: gemini-3.5-flash (Automatically falls back to default if 404).",
                        color = TechTextSecondary,
                        fontSize = 11.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = modelInput,
                            onValueChange = { modelInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .onFocusChanged {
                                    if (!it.isFocused && modelInput.isNotBlank()) {
                                        prefsManager.selectedModel = modelInput
                                    }
                                },
                            label = { Text("Model Name") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TechCyan,
                                unfocusedBorderColor = TechCyan.copy(alpha = 0.35f),
                                focusedLabelColor = TechCyan
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                prefsManager.selectedModel = modelInput
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TechElectricBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Set", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Language Preference (English, Hindi, Auto - Item 7)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = TechCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VOICE RECOGNITION & TTS LANGUAGE",
                            color = TechCyanBright,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val languages = listOf("auto" to "Auto (Device)", "en-US" to "English", "hi-IN" to "Hindi (हिंदी)")
                        languages.forEach { (code, label) ->
                            val isSelected = selectedLanguage == code
                            Surface(
                                color = if (isSelected) TechCyan else TechSurfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        selectedLanguage = code
                                        prefsManager.voiceLanguage = code
                                        VoiceEngine.getInstance(context).applyTtsLanguage()
                                    }
                                    .border(
                                        1.dp,
                                        if (isSelected) TechCyanBright else TechCyan.copy(alpha = 0.3f),
                                        RoundedCornerShape(16.dp)
                                    )
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) TechBlack else TechTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Privacy: Screen Content Sharing Setting (Item 9)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = if (shareScreenContent) TechSuccess else TechTextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Share Screen Context with AI",
                                    color = TechTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Default: OFF. Financial and password apps are strictly excluded.",
                                    color = TechTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = shareScreenContent,
                            onCheckedChange = {
                                shareScreenContent = it
                                prefsManager.isShareScreenEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TechBlack,
                                checkedTrackColor = TechCyan,
                                uncheckedThumbColor = TechTextMuted,
                                uncheckedTrackColor = TechSurfaceVariant
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 5. System Permissions Hub
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechElectricBlue.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SYSTEM PERMISSIONS HUB",
                        color = TechCyanBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Required for hands-free voice, floating hologram HUD, and screen click automation.",
                        color = TechTextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    PermissionStatusRow(
                        title = "Microphone (Voice Orders)",
                        description = "Enables speech recognizer and 'Hey TechChat' wake word",
                        isGranted = hasMicPermission,
                        icon = Icons.Default.Mic,
                        onGrantClick = onRequestMicPermission
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PermissionStatusRow(
                        title = "Draw Over Other Apps (Floating Hologram)",
                        description = "Shows the holographic core on top of YouTube & other apps",
                        isGranted = hasOverlayPermission,
                        icon = Icons.Default.Layers,
                        onGrantClick = {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PermissionStatusRow(
                        title = "Accessibility (Screen Vision & Clicks)",
                        description = "Reads screen elements, closes apps, and clicks buttons",
                        isGranted = hasAccessibility,
                        icon = Icons.Default.AccessibilityNew,
                        onGrantClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 6. Floating Overlay Control (Synchronized with isRunningFlow)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "FLOATING OVERLAY SERVICE",
                                color = TechCyanBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Keep holographic core floating over YouTube & other apps",
                                color = TechTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isOverlayActive,
                            onCheckedChange = { enable ->
                                if (!hasOverlayPermission) {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                    return@Switch
                                }

                                val intent = Intent(context, TechChatOverlayService::class.java).apply {
                                    action = if (enable) TechChatOverlayService.ACTION_START else TechChatOverlayService.ACTION_STOP
                                }
                                if (enable) {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                        context.startForegroundService(intent)
                                    } else {
                                        context.startService(intent)
                                    }
                                } else {
                                    context.startService(intent)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TechBlack,
                                checkedTrackColor = TechCyan,
                                uncheckedThumbColor = TechTextMuted,
                                uncheckedTrackColor = TechSurfaceVariant
                            )
                        )
                    }

                    HorizontalDivider(color = TechCyan.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isWakeWordRequired) "Wake Word Required" else "Always Listening",
                                color = TechTextPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = if (isWakeWordRequired) "Overlay reacts only to wake word + 12s active session" else "Overlay reacts to all recognized speech",
                                color = TechTextMuted,
                                fontSize = 10.5.sp
                            )
                        }

                        Switch(
                            checked = isWakeWordRequired,
                            onCheckedChange = {
                                isWakeWordRequired = it
                                prefsManager.isWakeWordRequiredForOverlay = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TechBlack,
                                checkedTrackColor = TechCyan,
                                uncheckedThumbColor = TechTextMuted,
                                uncheckedTrackColor = TechSurfaceVariant
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 7. Wake Word Customization (Item 1: Save only on blur or Save button)
            Card(
                colors = CardDefaults.cardColors(containerColor = TechCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "WAKE WORD TRIGGER",
                        color = TechCyanBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Saved on tapping Save or on losing focus. Blank defaults to 'hey techchat'.",
                        color = TechTextMuted,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = wakeWordInput,
                            onValueChange = { wakeWordInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .onFocusChanged {
                                    if (!it.isFocused) {
                                        prefsManager.wakeWord = wakeWordInput
                                    }
                                },
                            label = { Text("Wake Word") },
                            placeholder = { Text("hey techchat") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TechCyan,
                                unfocusedBorderColor = TechCyan.copy(alpha = 0.3f),
                                focusedLabelColor = TechCyan
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                prefsManager.wakeWord = wakeWordInput
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = TechBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AI Voice Speech Feedback",
                            color = TechTextPrimary,
                            fontSize = 13.sp
                        )
                        Switch(
                            checked = speechFeedback,
                            onCheckedChange = {
                                speechFeedback = it
                                prefsManager.isSpeechFeedbackEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TechBlack,
                                checkedTrackColor = TechCyan
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PermissionStatusRow(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onGrantClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TechSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isGranted) TechSuccess else TechCyan,
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TechTextPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                color = TechTextMuted,
                fontSize = 10.5.sp
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Granted",
                    tint = TechSuccess,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Active",
                    color = TechSuccess,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechElectricBlue.copy(alpha = 0.25f),
                    contentColor = TechCyanBright
                ),
                shape = RoundedCornerShape(6.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("Enable", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
