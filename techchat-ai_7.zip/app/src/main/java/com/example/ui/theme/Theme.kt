package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TechChatColorScheme = darkColorScheme(
    primary = TechCyan,
    onPrimary = TechBlack,
    primaryContainer = TechCard,
    onPrimaryContainer = TechCyanBright,
    secondary = TechElectricBlue,
    onSecondary = TechBlack,
    secondaryContainer = TechSurfaceVariant,
    onSecondaryContainer = TechCyanBright,
    tertiary = TechDeepBlue,
    background = TechBlack,
    onBackground = TechTextPrimary,
    surface = TechSurface,
    onSurface = TechTextPrimary,
    surfaceVariant = TechSurfaceVariant,
    onSurfaceVariant = TechTextSecondary,
    outline = TechDeepBlue.copy(alpha = 0.5f),
    outlineVariant = TechCyan.copy(alpha = 0.3f),
    error = TechError
)

@Composable
fun TechChatTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TechChatColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TechChatTheme(content = content)
}
