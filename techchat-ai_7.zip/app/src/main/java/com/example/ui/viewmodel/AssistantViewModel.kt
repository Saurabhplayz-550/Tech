package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PreferencesManager
import com.example.service.ActionProcessor
import com.example.service.GeminiService
import com.example.service.TechChatOverlayService
import com.example.service.VoiceClient
import com.example.service.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AssistantStatus {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    EXECUTING
}

data class CommandLog(
    val id: Long = System.currentTimeMillis(),
    val query: String,
    val response: String,
    val isSystemAction: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication()
    val prefsManager = PreferencesManager(context)
    private val geminiService = GeminiService()
    val voiceEngine = VoiceEngine.getInstance(context)
    private val actionProcessor = ActionProcessor(context, prefsManager, geminiService)

    private val _status = MutableStateFlow(AssistantStatus.IDLE)
    val status: StateFlow<AssistantStatus> = _status.asStateFlow()

    private val _spokenText = MutableStateFlow("")
    val spokenText: StateFlow<String> = _spokenText.asStateFlow()

    private val _aiResponse = MutableStateFlow("TechChat AI Core initialized. Tap mic or type order.")
    val aiResponse: StateFlow<String> = _aiResponse.asStateFlow()

    val audioAmplitude: StateFlow<Float> = voiceEngine.amplitude

    private val _commandLogs = MutableStateFlow<List<CommandLog>>(emptyList())
    val commandLogs: StateFlow<List<CommandLog>> = _commandLogs.asStateFlow()

    // Shared state flow directly tied to service lifecycle (Item 11)
    val isOverlayRunning: StateFlow<Boolean> = TechChatOverlayService.isRunningFlow

    init {
        // Collect spoken text from voice engine
        viewModelScope.launch {
            voiceEngine.spokenText.collect { text ->
                _spokenText.value = text
            }
        }

        // Keep status synchronized with VoiceEngine speaking and listening states
        viewModelScope.launch {
            voiceEngine.isSpeaking.collect { isSpeaking ->
                if (isSpeaking) {
                    _status.value = AssistantStatus.SPEAKING
                } else if (_status.value == AssistantStatus.SPEAKING) {
                    _status.value = AssistantStatus.IDLE
                }
            }
        }

        viewModelScope.launch {
            voiceEngine.isListening.collect { isListening ->
                if (isListening && _status.value != AssistantStatus.THINKING && _status.value != AssistantStatus.EXECUTING) {
                    _status.value = AssistantStatus.LISTENING
                } else if (!isListening && _status.value == AssistantStatus.LISTENING) {
                    _status.value = AssistantStatus.IDLE
                }
            }
        }

        // Register dedicated listener for ACTIVITY client (Item 5)
        voiceEngine.registerListener(VoiceClient.ACTIVITY) { text ->
            processUserCommand(text)
        }
    }

    fun onResume() {
        voiceEngine.setClientInForeground(VoiceClient.ACTIVITY)
    }

    fun onPause() {
        // Switch to OVERLAY and restart overlay listening if overlay is active (Item 6)
        if (TechChatOverlayService.isRunning) {
            voiceEngine.setClientInForeground(VoiceClient.OVERLAY)
            voiceEngine.startContinuousListening(VoiceClient.OVERLAY)
        } else {
            voiceEngine.releaseClient(VoiceClient.ACTIVITY)
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        _status.value = AssistantStatus.SPEAKING
        voiceEngine.speak(text) {
            _status.value = AssistantStatus.IDLE
            onDone?.invoke()
        }
    }

    fun stopSpeaking() {
        voiceEngine.stopSpeaking()
        _status.value = AssistantStatus.IDLE
    }

    fun toggleListening() {
        if (voiceEngine.isListening.value) {
            voiceEngine.stopContinuousListening(VoiceClient.ACTIVITY)
            _status.value = AssistantStatus.IDLE
        } else {
            _status.value = AssistantStatus.LISTENING
            voiceEngine.startContinuousListening(VoiceClient.ACTIVITY)
        }
    }

    fun processUserCommand(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return

        // Guard against duplicate overlapping commands while Gemini is in flight (Item 8)
        if (voiceEngine.isProcessingAi) {
            Log.d("AssistantViewModel", "Ignoring command: AI query in flight")
            return
        }

        _spokenText.value = trimmed

        // Check 1: Fast Path (YouTube, WhatsApp, Button Click, Face)
        val fastResult = actionProcessor.tryExecuteFastPath(trimmed)
        if (fastResult != null) {
            _status.value = if (fastResult.isSystemAction) AssistantStatus.EXECUTING else AssistantStatus.SPEAKING
            _aiResponse.value = fastResult.spokenResponse
            addLog(trimmed, fastResult.spokenResponse, fastResult.isSystemAction)

            speak(fastResult.spokenResponse) {
                _status.value = AssistantStatus.IDLE
            }
            return
        }

        // Check 2: General Gemini Query & Structured Device Action
        _status.value = AssistantStatus.THINKING
        voiceEngine.isProcessingAi = true

        viewModelScope.launch {
            try {
                val executionResult = actionProcessor.processWithGemini(trimmed) { steps ->
                    val planText = actionProcessor.planToSpeech(steps)
                    _aiResponse.value = planText
                    voiceEngine.speakAndWait(planText)
                }
                _aiResponse.value = executionResult.spokenResponse
                addLog(trimmed, executionResult.spokenResponse, executionResult.isSystemAction)

                speak(executionResult.spokenResponse) {
                    _status.value = AssistantStatus.IDLE
                }
            } catch (e: Exception) {
                val errorMsg = "Core error: ${e.message ?: "Failed to process command"}"
                _aiResponse.value = errorMsg
                addLog(trimmed, errorMsg, false)
                speak(errorMsg) {
                    _status.value = AssistantStatus.IDLE
                }
            } finally {
                voiceEngine.isProcessingAi = false
                if (_status.value == AssistantStatus.THINKING || _status.value == AssistantStatus.EXECUTING) {
                    _status.value = AssistantStatus.IDLE
                }
            }
        }
    }

    private fun addLog(query: String, response: String, isSystemAction: Boolean = false) {
        _commandLogs.value = listOf(
            CommandLog(query = query, response = response, isSystemAction = isSystemAction)
        ) + _commandLogs.value.take(20)
    }

    fun toggleOverlayService() {
        if (!Settings.canDrawOverlays(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return
        }

        if (TechChatOverlayService.isRunning) {
            val intent = Intent(context, TechChatOverlayService::class.java).apply {
                action = TechChatOverlayService.ACTION_STOP
            }
            context.startService(intent)
        } else {
            val intent = Intent(context, TechChatOverlayService::class.java).apply {
                action = TechChatOverlayService.ACTION_START
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.unregisterListener(VoiceClient.ACTIVITY)
        voiceEngine.releaseClient(VoiceClient.ACTIVITY)
        // Resume overlay listening if overlay service is still running in background (Item 6)
        if (TechChatOverlayService.isRunning) {
            voiceEngine.setClientInForeground(VoiceClient.OVERLAY)
            voiceEngine.startContinuousListening(VoiceClient.OVERLAY)
        }
    }
}
