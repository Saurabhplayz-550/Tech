package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.BuildConfig

class PreferencesManager(context: Context) {

    private val plainPrefs: SharedPreferences =
        context.getSharedPreferences("techchat_prefs", Context.MODE_PRIVATE)

    private val securePrefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "techchat_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.w("PreferencesManager", "Failed to create EncryptedSharedPreferences, using standard prefs", e)
        plainPrefs
    }

    companion object {
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_MODEL = "gemini_model"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_SPEECH_ENABLED = "speech_enabled"
        private const val KEY_OVERLAY_AUTO_START = "overlay_auto_start"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_TTS_SPEED = "tts_speed"
        private const val KEY_VOICE_LANGUAGE = "voice_language"
        private const val KEY_SHARE_SCREEN = "share_screen_content"
        private const val KEY_OVERLAY_WAKE_WORD_REQUIRED = "overlay_wake_word_required"

        const val DEFAULT_MODEL = "gemini-2.5-flash"
        const val DEFAULT_WAKE_WORD = "hey techchat"
        const val DEFAULT_LANGUAGE = "auto"
    }

    init {
        // Migrate legacy unencrypted API key if present
        migrateLegacyApiKey()
    }

    private fun migrateLegacyApiKey() {
        val oldKey = plainPrefs.getString(KEY_GEMINI_API_KEY, null)
        if (!oldKey.isNullOrBlank()) {
            if (securePrefs !== plainPrefs) {
                securePrefs.edit().putString(KEY_GEMINI_API_KEY, oldKey).apply()
                plainPrefs.edit().remove(KEY_GEMINI_API_KEY).apply()
            }
        }
    }

    var geminiApiKey: String
        get() {
            val savedKey = securePrefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
            if (savedKey.isNotBlank()) return savedKey

            // Fallback to BuildConfig if configured in environment
            return try {
                val buildConfigKey = BuildConfig.GEMINI_API_KEY
                if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
                    buildConfigKey
                } else ""
            } catch (e: Exception) {
                ""
            }
        }
        set(value) {
            val trimmed = value.trim()
            securePrefs.edit().putString(KEY_GEMINI_API_KEY, trimmed).apply()
            if (securePrefs !== plainPrefs) {
                plainPrefs.edit().remove(KEY_GEMINI_API_KEY).apply()
            }
        }

    var selectedModel: String
        get() {
            val model = plainPrefs.getString(KEY_MODEL, DEFAULT_MODEL)?.trim() ?: DEFAULT_MODEL
            return if (model.isBlank()) DEFAULT_MODEL else model
        }
        set(value) {
            val toSave = value.trim()
            plainPrefs.edit().putString(KEY_MODEL, if (toSave.isBlank()) DEFAULT_MODEL else toSave).apply()
        }

    var wakeWord: String
        get() {
            val word = plainPrefs.getString(KEY_WAKE_WORD, DEFAULT_WAKE_WORD)?.trim() ?: DEFAULT_WAKE_WORD
            return if (word.isBlank()) DEFAULT_WAKE_WORD else word
        }
        set(value) {
            val trimmed = value.trim()
            val toSave = if (trimmed.isBlank()) DEFAULT_WAKE_WORD else trimmed
            plainPrefs.edit().putString(KEY_WAKE_WORD, toSave).apply()
        }

    var voiceLanguage: String
        get() = plainPrefs.getString(KEY_VOICE_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
        set(value) = plainPrefs.edit().putString(KEY_VOICE_LANGUAGE, value).apply()

    var isShareScreenEnabled: Boolean
        get() = plainPrefs.getBoolean(KEY_SHARE_SCREEN, true) // ON by default: needed so the assistant can see the screen and tap
        set(value) = plainPrefs.edit().putBoolean(KEY_SHARE_SCREEN, value).apply()

    var isSpeechFeedbackEnabled: Boolean
        get() = plainPrefs.getBoolean(KEY_SPEECH_ENABLED, true)
        set(value) = plainPrefs.edit().putBoolean(KEY_SPEECH_ENABLED, value).apply()

    var isOverlayEnabled: Boolean
        get() = plainPrefs.getBoolean(KEY_OVERLAY_AUTO_START, true)
        set(value) = plainPrefs.edit().putBoolean(KEY_OVERLAY_AUTO_START, value).apply()

    var isWakeWordRequiredForOverlay: Boolean
        get() = plainPrefs.getBoolean(KEY_OVERLAY_WAKE_WORD_REQUIRED, true) // Default Wake word required
        set(value) = plainPrefs.edit().putBoolean(KEY_OVERLAY_WAKE_WORD_REQUIRED, value).apply()

    var ttsPitch: Float
        get() = plainPrefs.getFloat(KEY_TTS_PITCH, 1.0f)
        set(value) = plainPrefs.edit().putFloat(KEY_TTS_PITCH, value).apply()

    var ttsSpeed: Float
        get() = plainPrefs.getFloat(KEY_TTS_SPEED, 1.05f)
        set(value) = plainPrefs.edit().putFloat(KEY_TTS_SPEED, value).apply()

    // One-time setup prompts (overlay / accessibility / battery) so we never nag repeatedly
    fun wasPrompted(key: String): Boolean = plainPrefs.getBoolean("prompted_$key", false)

    fun markPrompted(key: String) {
        plainPrefs.edit().putBoolean("prompted_$key", true).apply()
    }
}
