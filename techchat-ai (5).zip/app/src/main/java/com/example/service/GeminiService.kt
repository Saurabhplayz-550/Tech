package com.example.service

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val role: String, val text: String)

data class GeminiAction(
    val action: String = "none",
    val target: String = "",
    val text: String = "",
    val speech: String = "",
    val speechForTts: String = if (speech.length > 600) speech.take(590) + "..." else speech
)

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "GeminiService"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        const val FALLBACK_MODEL = "gemini-2.5-flash"
    }

    // In-memory conversation history (Item 21: max 6 turns, cleared on restart)
    private val conversationHistory = mutableListOf<ChatMessage>()

    fun clearHistory() {
        synchronized(conversationHistory) {
            conversationHistory.clear()
        }
    }

    suspend fun generateContent(
        apiKey: String,
        prompt: String,
        model: String = FALLBACK_MODEL,
        screenContext: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API Key is not set. Please configure it in Settings.")
            )
        }

        var activeModel = model.ifBlank { FALLBACK_MODEL }
        var hasTriedFallback = false
        var attempt = 0
        val maxAttempts = 3

        while (attempt < maxAttempts) {
            attempt++
            try {
                val url = "$BASE_URL/$activeModel:generateContent"

                val systemInstructionText = """
                    You are TechChat AI, an ultra-advanced holographic AI assistant on Android 10.
                    You are capable of conversational Q&A as well as executing Android device actions.
                    You understand both English and Hindi/Hinglish.

                    IMPORTANT OUTPUT RULES:
                    Output MUST be a strict JSON object matching the requested schema.
                    For open_app action: target should be the app name in plain English (e.g. 'YouTube', 'WhatsApp', 'Chrome', 'Gmail', 'Spotify', 'Settings' - the app resolves it to package).
                    For click action: target should be the button label text.
                    For send_whatsapp: target can be the contact name (e.g. 'Mom'), text is the message body.
                    For phone control orders: return action as open_app|go_home|go_back|click|type_text|send_whatsapp.
                    For general questions, advice, chit-chat, return action as 'none'.
                    speech must contain a crisp, polite conversational reply suitable for voice playback.
                    ${if (!screenContext.isNullOrBlank()) "Active screen context: $screenContext" else ""}
                """.trimIndent()

                // History: Send last 6 turns (user/model) for follow-up support (Item 21)
                val contentsArray = JSONArray()
                val historySnapshot = synchronized(conversationHistory) {
                    conversationHistory.takeLast(6).toList()
                }

                for (turn in historySnapshot) {
                    contentsArray.put(
                        JSONObject().apply {
                            put("role", turn.role)
                            put("parts", JSONArray().apply { put(JSONObject().put("text", turn.text)) })
                        }
                    )
                }

                // Add current prompt
                contentsArray.put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply { put(JSONObject().put("text", prompt)) })
                    }
                )

                // JSON schema configuration (Item 18)
                val responseSchema = JSONObject().apply {
                    put("type", "OBJECT")
                    put(
                        "properties",
                        JSONObject().apply {
                            put(
                                "action",
                                JSONObject().apply {
                                    put("type", "STRING")
                                    put(
                                        "enum",
                                        JSONArray(
                                            listOf(
                                                "open_app",
                                                "go_home",
                                                "go_back",
                                                "click",
                                                "type_text",
                                                "send_whatsapp",
                                                "none"
                                            )
                                        )
                                    )
                                }
                            )
                            put("target", JSONObject().put("type", "STRING"))
                            put("text", JSONObject().put("type", "STRING"))
                            put("speech", JSONObject().put("type", "STRING"))
                        }
                    )
                    put("required", JSONArray(listOf("action", "speech")))
                }

                val requestJson = JSONObject().apply {
                    put("contents", contentsArray)
                    put(
                        "systemInstruction",
                        JSONObject().apply {
                            put(
                                "parts",
                                JSONArray().apply {
                                    put(JSONObject().put("text", systemInstructionText))
                                }
                            )
                        }
                    )
                    put(
                        "generationConfig",
                        JSONObject().apply {
                            put("temperature", 0.7)
                            put("maxOutputTokens", 1024)
                            put("responseMimeType", "application/json")
                            put("responseSchema", responseSchema)
                        }
                    )
                }

                val body = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("x-goog-api-key", apiKey)
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                val responseCode = response.code
                val responseBody = response.body?.string() ?: ""

                // 404 Model Not Found fallback (Item 20)
                if (responseCode == 404) {
                    if (!hasTriedFallback && activeModel != FALLBACK_MODEL) {
                        Log.w(TAG, "Model $activeModel returned 404. Falling back to $FALLBACK_MODEL")
                        activeModel = FALLBACK_MODEL
                        hasTriedFallback = true
                        continue
                    } else {
                        val msg = "Model '$model' was not found (404) and fallback '$FALLBACK_MODEL' also failed."
                        return@withContext Result.failure(Exception(msg))
                    }
                }

                // 429 Rate Limit or 5xx Server Error retry with backoff
                if ((responseCode == 429 || responseCode in 500..599) && attempt < maxAttempts) {
                    val backoff = 700L * attempt
                    Log.w(TAG, "HTTP $responseCode from Gemini API. Retrying in ${backoff}ms...")
                    delay(backoff)
                    continue
                }

                if (!response.isSuccessful) {
                    val errorMsg = try {
                        val errorObj = JSONObject(responseBody).optJSONObject("error")
                        errorObj?.optString("message") ?: "HTTP $responseCode: $responseBody"
                    } catch (e: Exception) {
                        "HTTP $responseCode: $responseBody"
                    }
                    return@withContext Result.failure(Exception(errorMsg))
                }

                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    val promptFeedback = json.optJSONObject("promptFeedback")
                    val blockReason = promptFeedback?.optString("blockReason")
                    val message = if (!blockReason.isNullOrBlank()) {
                        "Content blocked by safety policy ($blockReason)"
                    } else {
                        "No response candidates returned by Gemini"
                    }
                    return@withContext Result.failure(Exception(message))
                }

                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")

                val combinedText = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val partObj = parts.getJSONObject(i)
                        val isThought = partObj.optBoolean("thought", false)
                        if (!isThought) {
                            val textPart = partObj.optString("text")
                            if (!textPart.isNullOrBlank()) {
                                combinedText.append(textPart)
                            }
                        }
                    }
                }

                val finalText = combinedText.toString().trim()

                if (finalText.isBlank()) {
                    val finishReason = firstCandidate.optString("finishReason")
                    val msg = when (finishReason) {
                        "SAFETY" -> "Response was filtered due to safety guidelines."
                        "MAX_TOKENS" -> "Response reached the maximum token limit."
                        "RECITATION" -> "Response was omitted due to recitation check."
                        else -> "Gemini returned an empty response ($finishReason)."
                    }
                    return@withContext Result.failure(Exception(msg))
                }

                // Save to conversation history
                synchronized(conversationHistory) {
                    conversationHistory.add(ChatMessage("user", prompt))
                    conversationHistory.add(ChatMessage("model", finalText))
                    if (conversationHistory.size > 14) {
                        val removeCount = conversationHistory.size - 12
                        for (r in 0 until removeCount) {
                            conversationHistory.removeAt(0)
                        }
                    }
                }

                return@withContext Result.success(finalText)

            } catch (e: Exception) {
                if (attempt >= maxAttempts) {
                    return@withContext Result.failure(e)
                }
                delay(600L * attempt)
            }
        }

        Result.failure(Exception("Failed to obtain response after $maxAttempts attempts"))
    }

    fun parseActionResponse(rawResponse: String): GeminiAction {
        var clean = rawResponse.trim()

        // Strip code fences if any
        if (clean.startsWith("```")) {
            val lines = clean.lines()
            clean = lines.filterNot { it.startsWith("```") }.joinToString("\n").trim()
        }

        // Fallback: extract the first {...} block (Item 18)
        val firstBrace = clean.indexOf('{')
        val lastBrace = clean.lastIndexOf('}')
        if (firstBrace != -1 && lastBrace > firstBrace) {
            clean = clean.substring(firstBrace, lastBrace + 1)
        }

        return try {
            val json = JSONObject(clean)
            val action = json.optString("action", "none").lowercase()
            val target = json.optString("target", "")
            val text = json.optString("text", "")
            val speech = json.optString("speech", "")

            GeminiAction(
                action = action,
                target = target,
                text = text,
                speech = speech.ifBlank { rawResponse }
            )
        } catch (e: Exception) {
            GeminiAction(
                action = "none",
                target = "",
                text = "",
                speech = rawResponse
            )
        }
    }
}
