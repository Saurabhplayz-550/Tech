package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.PreferencesManager
import com.example.ui.hologram.BlueHologramCore
import com.example.ui.theme.TechChatTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TechChatOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "TechChatOverlayService"
        private const val CHANNEL_ID = "techchat_service_channel"
        private const val NOTIFICATION_ID = 2001

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SUMMON = "ACTION_SUMMON"

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()

        val isRunning: Boolean get() = _isRunningFlow.value
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private lateinit var prefsManager: PreferencesManager
    private val geminiService = GeminiService()
    private lateinit var actionProcessor: ActionProcessor
    private lateinit var voiceEngine: VoiceEngine

    private val isHologramVisible = MutableStateFlow(true)
    private val handler = Handler(Looper.getMainLooper())

    // Timer management: cancel pending shrink so timers never stack (Item 2)
    private val shrinkRunnable = Runnable {
        isHologramVisible.value = false
    }

    // Active session window for overlay wake-word gating (Item 7: 12 seconds)
    private var activeSessionUntilMs = 0L

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        prefsManager = PreferencesManager(this)
        actionProcessor = ActionProcessor(this, prefsManager, geminiService)
        voiceEngine = VoiceEngine.getInstance(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        createNotificationChannel()

        // Register dedicated listener for OVERLAY client (Item 5)
        voiceEngine.registerListener(VoiceClient.OVERLAY) { command ->
            processOverlayVoiceCommand(command)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SUMMON -> {
                summonHologram("How can I assist you, sir?")
            }
            else -> {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Overlay permission is required to display TechChat AI", Toast.LENGTH_LONG).show()
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForeground(NOTIFICATION_ID, createNotification())
                _isRunningFlow.value = true
                showOverlayWindow()
                summonHologram("TechChat AI Core online.")
            }
        }
        return START_STICKY
    }

    private fun extendActiveSession() {
        activeSessionUntilMs = System.currentTimeMillis() + 12_000L
    }

    private fun isSessionActive(): Boolean {
        return System.currentTimeMillis() < activeSessionUntilMs
    }

    private fun scheduleShrink(delayMs: Long = 6000L) {
        handler.removeCallbacks(shrinkRunnable)
        handler.postDelayed(shrinkRunnable, delayMs)
    }

    private fun summonHologram(greeting: String) {
        isHologramVisible.value = true
        extendActiveSession()
        voiceEngine.speak(greeting) {
            scheduleShrink(6000L)
        }
        voiceEngine.startContinuousListening(VoiceClient.OVERLAY)
    }

    private fun processOverlayVoiceCommand(query: String) {
        if (voiceEngine.isProcessingAi) {
            Log.d(TAG, "Ignoring overlay voice input: AI request already in flight")
            return
        }

        val normalized = actionProcessor.normalizeText(query)
        if (normalized.isBlank()) return

        Log.i(TAG, "Overlay received voice: $query")

        val isWake = actionProcessor.isWakeWord(query)
        val sessionActive = isSessionActive()
        val wakeRequired = prefsManager.isWakeWordRequiredForOverlay

        // Wake-word gate (Item 7)
        if (wakeRequired && !sessionActive && !isWake) {
            Log.d(TAG, "Ignored: wake word required and no active session")
            return
        }

        // If wake word was detected or session is active, extend session
        extendActiveSession()

        // If wake word is followed by a command in the same sentence (Item 7)
        val stripped = if (isWake) actionProcessor.stripWakeWord(query) else query

        // If user only said the wake word ("Hey TechChat")
        if (isWake && stripped.isBlank()) {
            summonHologram("How can I assist you, sir?")
            return
        }

        val effectiveQuery = stripped.ifBlank { query }

        // Fast Path Execution
        val fastResult = actionProcessor.tryExecuteFastPath(effectiveQuery)
        if (fastResult != null) {
            if (fastResult.showHologramFace) {
                isHologramVisible.value = true
            }
            voiceEngine.speak(fastResult.spokenResponse) {
                scheduleShrink(6000L)
            }
            return
        }

        // General Gemini reasoning & structured action execution
        voiceEngine.isProcessingAi = true
        serviceScope.launch {
            try {
                val executionResult = actionProcessor.processWithGemini(effectiveQuery)
                voiceEngine.speak(executionResult.spokenResponse) {
                    scheduleShrink(6000L)
                }
            } finally {
                voiceEngine.isProcessingAi = false
            }
        }
    }

    private fun showOverlayWindow() {
        if (overlayView != null) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }
        windowParams = params

        val container = FrameLayout(this)
        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@TechChatOverlayService)
            setViewTreeSavedStateRegistryOwner(this@TechChatOverlayService)
            setContent {
                TechChatTheme {
                    val visible = isHologramVisible.collectAsState().value
                    val listening = voiceEngine.isListening.collectAsState().value
                    val speaking = voiceEngine.isSpeaking.collectAsState().value
                    val amp = voiceEngine.amplitude.collectAsState().value

                    if (visible) {
                        BlueHologramCore(
                            coreSize = 260.dp,
                            isListening = listening,
                            isSpeaking = speaking,
                            audioAmplitude = amp,
                            onClick = {
                                summonHologram("Listening, sir.")
                            },
                            onDragWindow = { dx, dy ->
                                moveOverlayWindow(dx, dy)
                            }
                        )
                    } else {
                        // 72dp floating holographic orb (Item 3: Drag moves window, Tap summons)
                        BlueHologramCore(
                            coreSize = 72.dp,
                            isListening = listening,
                            isSpeaking = speaking,
                            audioAmplitude = amp,
                            onClick = {
                                summonHologram("TechChat at your service.")
                            },
                            onDragWindow = { dx, dy ->
                                moveOverlayWindow(dx, dy)
                            }
                        )
                    }
                }
            }
        }

        container.addView(composeView)
        overlayView = container

        try {
            windowManager.addView(container, params)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlay view to WindowManager", e)
        }
    }

    // Moves overlay window and clamps x/y to screen bounds (Item 4)
    private fun moveOverlayWindow(dx: Float, dy: Float) {
        val params = windowParams ?: return
        val view = overlayView ?: return

        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        val halfWidth = screenWidth / 2
        val halfHeight = screenHeight / 2

        params.x = (params.x + dx.toInt()).coerceIn(-halfWidth + 40, halfWidth - 40)
        params.y = (params.y + dy.toInt()).coerceIn(-halfHeight + 60, halfHeight - 60)

        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update overlay view layout", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "TechChat Hologram Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps TechChat AI Hologram active over apps"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TechChat AI Core Active")
            .setContentText("Holographic Assistant running over apps.")
            .setSmallIcon(R.drawable.ic_notification_core)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunningFlow.value = false
        handler.removeCallbacks(shrinkRunnable)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()

        voiceEngine.unregisterListener(VoiceClient.OVERLAY)
        voiceEngine.releaseClient(VoiceClient.OVERLAY)

        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing overlay", e)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
